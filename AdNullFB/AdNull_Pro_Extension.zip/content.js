// AdNull Blocker Pro v8.1 - Content Script
// Multi-platform ready: Facebook, TikTok, Instagram

(function() {
    'use strict';
    
    const VERSION = '8.1';
    const isBlockingTab = location.href.includes('__adnull_block=1');
    
    console.log('[AdNull] Content script v' + VERSION, '| Blocking:', isBlockingTab, '| URL:', location.href.substring(0, 50));
    
    // ══════════════════════════════════════════════════════════════════════
    // STATE
    // ══════════════════════════════════════════════════════════════════════
    let dashboardReady = false;
    let state = null;
    let reelsSkipperInterval = null;
    
    // Reels Skipper Configuration
    let reelsSkipSpeed = 2000; // Default 2 seconds
    let reelsSkipMethod = 'button'; // 'button' or 'keyboard'
    
    // ══════════════════════════════════════════════════════════════════════
    // UTILITIES
    // ══════════════════════════════════════════════════════════════════════
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    
    function waitFor(fn, maxTries = 80, interval = 100) {
        return new Promise((resolve, reject) => {
            let tries = 0;
            const check = setInterval(() => {
                tries++;
                try {
                    const result = fn();
                    if (result) { clearInterval(check); resolve(result); }
                    else if (tries >= maxTries) { clearInterval(check); reject(new Error('Timeout')); }
                } catch (e) { clearInterval(check); reject(e); }
            }, interval);
        });
    }
    
    function isVisible(el) {
        if (!el) return false;
        const style = getComputedStyle(el);
        const rect = el.getBoundingClientRect();
        return style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 0 && rect.height > 0;
    }
    
    // ══════════════════════════════════════════════════════════════════════
    // PAGE DETECTION
    // ══════════════════════════════════════════════════════════════════════
    function getPageType() {
        const path = location.pathname;
        if (path === '/' || path === '/home' || path === '/home.php') return 'feed';
        if (path.includes('/reel') || path.includes('/reels')) return 'reels';
        if (path.includes('/watch')) return 'watch';
        if (path.includes('/stories')) return 'stories';
        if (/^\/(profile\.php|[a-zA-Z0-9._-]+)\/?$/.test(path) && path.length > 1) return 'profile';
        return 'other';
    }
    
    function getPageIcon() {
        const icons = { feed: '📰', reels: '🎬', watch: '📺', stories: '📖', profile: '👤', other: '📄' };
        return icons[getPageType()] || '📄';
    }
    
    function getPageLabel() {
        const labels = { feed: 'Feed', reels: 'Reels', watch: 'Watch', stories: 'Stories', profile: 'Profile', other: 'Page' };
        return labels[getPageType()] || 'Page';
    }
    
    // ══════════════════════════════════════════════════════════════════════
    // SPONSORED DETECTION
    // ══════════════════════════════════════════════════════════════════════
    function isSponsored(post) {
        for (const span of post.querySelectorAll('span[dir="auto"]')) {
            const text = span.innerText?.trim();
            if (['Sponsored', 'Sponsorisé', 'Publicidad', 'Gesponsert', 'Sponsorlu', 'Sponsorizzato'].includes(text)) {
                return { method: 'text' };
            }
        }
        
        for (const link of post.querySelectorAll('a[href*="__cft__[0]="]')) {
            if (!link.href.includes('/groups/') && !link.href.includes('/events/')) {
                return { method: 'tracking' };
            }
        }
        
        const canvas = post.querySelector('a > span > span[aria-labelledby] > canvas');
        if (canvas) {
            const labelId = canvas.parentElement.getAttribute('aria-labelledby');
            if (labelId) {
                try {
                    const label = document.querySelector(`[id="${labelId.replace(/:/g, '\\:')}"]`);
                    if (label && /Sponsored|Sponsorisé|Publicidad|Gesponsert/i.test(label.innerText)) {
                        return { method: 'canvas' };
                    }
                } catch (e) {}
            }
        }
        
        for (const el of post.querySelectorAll('[aria-label="Sponsored"]')) {
            return { method: 'aria' };
        }
        
        if (post.querySelector('a[href*="/ads/about"]') || post.querySelector('a[href*="/ads/preferences"]')) {
            return { method: 'adlink' };
        }
        
        return null;
    }
    
    function isReelSponsored(container) {
        // Method 1: Direct "Sponsored" text - most reliable
        const text = container.innerText || '';
        if (/\bSponsored\b/i.test(text)) return { method: 'text' };
        
        // Method 2: External links with fbclid (advertiser redirect to non-FB site)
        for (const link of container.querySelectorAll('a[href*="fbclid"]')) {
            try {
                const url = new URL(link.href);
                // Must be going to an EXTERNAL site (not facebook.com)
                if (!url.hostname.includes('facebook.com') && !url.hostname.includes('fb.com')) {
                    return { method: 'external_fbclid' };
                }
            } catch (e) {}
        }
        
        // Method 3: rel="nofollow" links to external advertiser sites
        for (const link of container.querySelectorAll('a[rel="nofollow"]')) {
            try {
                const url = new URL(link.href);
                if (!url.hostname.includes('facebook.com') && !url.hostname.includes('fb.com')) {
                    return { method: 'nofollow_external' };
                }
            } catch (e) {}
        }
        
        // Method 4: CTA buttons that link to EXTERNAL sites
        const ctaPatterns = /^(learn more|shop now|sign up|get offer|buy now|install now|download|subscribe|get started|book now|order now|apply now|try now|watch more|see more details|get quote|contact us|visit site|see menu|request time|send message|call now|get directions|listen now|play now|use app|open link|view more)$/i;
        for (const link of container.querySelectorAll('a[href]')) {
            const linkText = link.innerText?.trim();
            if (linkText && ctaPatterns.test(linkText)) {
                try {
                    const url = new URL(link.href);
                    // CTA must link to external site to be sponsored
                    if (!url.hostname.includes('facebook.com') && !url.hostname.includes('fb.com')) {
                        return { method: 'cta_external' };
                    }
                } catch (e) {}
            }
        }
        
        // Method 5: Links with utm_source=fb or utm_medium=paid going to EXTERNAL sites
        for (const link of container.querySelectorAll('a[href*="utm_"]')) {
            if (link.href.includes('utm_source=fb') || link.href.includes('utm_medium=paid')) {
                try {
                    const url = new URL(link.href);
                    if (!url.hostname.includes('facebook.com') && !url.hostname.includes('fb.com')) {
                        return { method: 'utm_external' };
                    }
                } catch (e) {}
            }
        }
        
        // Method 6: Styled CTA buttons going to external sites
        for (const link of container.querySelectorAll('a[style*="background-color"]')) {
            try {
                const url = new URL(link.href);
                if (!url.hostname.includes('facebook.com') && !url.hostname.includes('fb.com')) {
                    return { method: 'styled_cta' };
                }
            } catch (e) {}
        }
        
        return null;
    }
    
    // ══════════════════════════════════════════════════════════════════════
    // DATA EXTRACTION
    // ══════════════════════════════════════════════════════════════════════
    function extractPostData(post) {
        const data = { author: 'Unknown', url: null, content: '', source: 'feed', platform: 'facebook' };
        
        for (const link of post.querySelectorAll('h2 a, h3 a, h4 a, strong a')) {
            const href = link.href;
            if (!href || href.includes('/groups/') || href.includes('/events/') || 
                href.includes('/ads/') || href.includes('/watch/') || href.includes('/reel/') ||
                href.includes('/photo/') || href.includes('/video/') || href.includes('#')) continue;
            
            try {
                const url = new URL(href);
                const parts = url.pathname.split('/').filter(p => p);
                if (parts[0] === 'profile.php' && url.searchParams.has('id')) {
                    data.author = link.innerText?.trim() || 'Profile';
                    data.url = `https://www.facebook.com/profile.php?id=${url.searchParams.get('id')}`;
                    break;
                }
                if (/^[a-zA-Z0-9._-]+$/.test(parts[0]) &&
                    !['home', 'watch', 'marketplace', 'gaming', 'events', 'pages', 'groups', 'stories'].includes(parts[0])) {
                    data.author = link.innerText?.trim() || parts[0];
                    data.url = `https://www.facebook.com/${parts[0]}`;
                    break;
                }
            } catch (e) {}
        }
        
        const contentDiv = post.querySelector('div[dir="auto"]');
        if (contentDiv) data.content = contentDiv.innerText?.substring(0, 100).replace(/\n/g, ' ') || '';
        
        return data;
    }
    
    function extractReelData(container) {
        const data = { author: 'Unknown', url: null, content: '', source: 'reel', platform: 'facebook' };
        
        const profileLink = container.querySelector('a[aria-label="See Owner Profile"]');
        if (profileLink) {
            const href = profileLink.href || profileLink.getAttribute('href') || '';
            try {
                const url = new URL(href.startsWith('http') ? href : 'https://www.facebook.com' + href);
                if (url.pathname.includes('profile.php') && url.searchParams.has('id')) {
                    data.url = `https://www.facebook.com/profile.php?id=${url.searchParams.get('id')}`;
                } else {
                    const parts = url.pathname.split('/').filter(p => p);
                    if (parts[0] && /^[a-zA-Z0-9._-]+$/.test(parts[0])) {
                        data.url = `https://www.facebook.com/${parts[0]}`;
                    }
                }
            } catch (e) {}
        }
        
        const nameEl = container.querySelector('h2 span') || container.querySelector('[aria-label="See Owner Profile"] + div span');
        if (nameEl) {
            const text = nameEl.innerText?.trim();
            if (text && text.length < 100) data.author = text.split('\n')[0];
        }
        
        return data;
    }

    // ══════════════════════════════════════════════════════════════════════
    // VISUAL TAGGING
    // ══════════════════════════════════════════════════════════════════════
    function tagPost(post) {
        if (post.querySelector('.adnull-tag')) return;
        const tag = document.createElement('div');
        tag.className = 'adnull-tag';
        tag.innerHTML = '<span class="tag-icon">🚫</span><span>SPONSOR</span>';
        const header = post.querySelector('h2, h3, h4') || post.firstChild;
        if (header?.parentNode) header.parentNode.insertBefore(tag, header);
        else post.insertBefore(tag, post.firstChild);
    }
    
    function tagReel(container) {
        if (container.querySelector('.adnull-reel-tag')) return;
        const tag = document.createElement('div');
        tag.className = 'adnull-reel-tag';
        tag.innerHTML = '🚫 SPONSORED REEL';
        if (getComputedStyle(container).position === 'static') container.style.position = 'relative';
        container.appendChild(tag);
    }
    
    function simulateDownKey() {
        // Match userscript exactly - dispatch to document.body
        const event = new KeyboardEvent('keydown', {
            key: 'ArrowDown',
            code: 'ArrowDown',
            keyCode: 40,
            which: 40,
            bubbles: true,
            cancelable: true
        });
        document.body.dispatchEvent(event);
    }
    
    function skipReel() {
        const notif = document.createElement('div');
        notif.className = 'adnull-skip-notif';
        notif.innerHTML = '<span>⏭️</span><span>SKIPPING AD</span>';
        document.body.appendChild(notif);
        setTimeout(() => notif.remove(), 1000);
        simulateDownKey();
    }
    
    function addBlockButton(post, url, name) {
        if (post.querySelector('.adnull-block-btn') || !url) return;
        const btn = document.createElement('button');
        btn.className = 'adnull-block-btn';
        btn.innerHTML = '🚫';
        btn.title = `Block ${name}`;
        btn.onclick = (e) => {
            e.preventDefault(); e.stopPropagation();
            chrome.runtime.sendMessage({ action: 'addToQueue', item: { url, author: name, source: 'manual' } });
            btn.innerHTML = '⏳';
            btn.classList.add('pending');
            btn.disabled = true;
            showToast(`Queued: ${name}`, 'success');
        };
        if (getComputedStyle(post).position === 'static') post.style.position = 'relative';
        post.appendChild(btn);
        post.onmouseenter = () => btn.classList.add('visible');
        post.onmouseleave = () => { if (!btn.disabled) btn.classList.remove('visible'); };
    }
    
    // ══════════════════════════════════════════════════════════════════════
    // SCANNING
    // ══════════════════════════════════════════════════════════════════════
    const processedPosts = new WeakSet();
    const processedReels = new Set();
    
    function scanFeed() {
        if (getPageType() !== 'feed') return { found: 0 };
        let found = 0;
        
        for (const post of document.querySelectorAll('div[role="article"]')) {
            if (processedPosts.has(post)) continue;
            processedPosts.add(post);
            
            const sponsored = isSponsored(post);
            if (sponsored) {
                const data = extractPostData(post);
                if (data.url) {
                    console.log('[AdNull] 🎯 Sponsor:', data.author);
                    tagPost(post);
                    chrome.runtime.sendMessage({ action: 'sponsorFound', data });
                    found++;
                }
            }
            
            if (state?.config?.showBlockButtons !== false) {
                const data = extractPostData(post);
                if (data.url) addBlockButton(post, data.url, data.author);
            }
        }
        
        return { found };
    }
    
    function scanReels() {
        const pageType = getPageType();
        if (pageType !== 'reels' && pageType !== 'watch') return { found: 0 };
        let found = 0;
        
        // Scan video containers with data-video-id
        for (const container of document.querySelectorAll('[data-video-id]')) {
            const rect = container.getBoundingClientRect();
            // More lenient viewport check - just needs to be partially visible
            if (rect.bottom < 0 || rect.top > window.innerHeight) continue;
            
            const videoId = container.getAttribute('data-video-id');
            if (!videoId || processedReels.has(videoId)) continue;
            processedReels.add(videoId);
            
            const sponsored = isReelSponsored(container);
            if (sponsored) {
                const data = extractReelData(container);
                console.log('[AdNull] 🎯 Sponsored reel detected:', sponsored.method, '| Author:', data.author);
                tagReel(container);
                
                if (data.url) {
                    chrome.runtime.sendMessage({ action: 'sponsorFound', data });
                    
                    if (state?.config?.skipSponsoredReels !== false) {
                        setTimeout(skipReel, 500);
                    }
                    found++;
                } else {
                    console.log('[AdNull] Sponsored reel but no profile URL extracted');
                }
            }
        }
        
        // Also scan for video articles (alternative structure)
        for (const article of document.querySelectorAll('div[role="article"]')) {
            if (processedPosts.has(article)) continue;
            
            const hasVideo = article.querySelector('video');
            if (!hasVideo) continue;
            
            processedPosts.add(article);
            
            const sponsored = isReelSponsored(article);
            if (sponsored) {
                const data = extractReelData(article);
                data.source = 'watch';
                console.log('[AdNull] 🎯 Sponsored video article:', sponsored.method, '| Author:', data.author);
                tagReel(article);
                
                if (data.url) {
                    chrome.runtime.sendMessage({ action: 'sponsorFound', data });
                    found++;
                }
            }
        }
        
        return { found };
    }
    
    // ══════════════════════════════════════════════════════════════════════
    // REELS AUTO-SKIPPER (Scan-first mode - waits for scan before skipping)
    // ══════════════════════════════════════════════════════════════════════
    function clickNextCardButton() {
        // Find the "Next Card" button by aria-label
        const nextBtn = document.querySelector('[aria-label="Next Card"]');
        if (nextBtn) {
            nextBtn.click();
            return true;
        }
        // Fallback: try to find any down arrow navigation button
        const downArrow = document.querySelector('div[role="button"] svg path[d*="57.47"]')?.closest('[role="button"]');
        if (downArrow) {
            downArrow.click();
            return true;
        }
        return false;
    }
    
    function skipToNextReel() {
        if (reelsSkipMethod === 'button') {
            if (!clickNextCardButton()) {
                // Fallback to keyboard if button not found
                simulateDownKey();
            }
        } else {
            simulateDownKey();
        }
    }
    
    // New scan-first skipper loop
    let reelsSkipperRunning = false;
    let lastScannedVideoId = null;
    
    async function reelsSkipperLoop() {
        if (!reelsSkipperRunning) return;
        
        try {
            // 1. Wait for video to load
            await waitForCurrentReel();
            
            // 2. Get current video ID
            const currentVideoId = getCurrentVideoId();
            
            // 3. Only scan if this is a new video
            if (currentVideoId && currentVideoId !== lastScannedVideoId) {
                lastScannedVideoId = currentVideoId;
                
                // 4. Scan the current reel
                const scanResult = scanReels();
                console.log('[AdNull] Scanned reel:', currentVideoId, 'Found:', scanResult.found);
                
                // Small delay to ensure scan data is sent
                await sleep(200);
            }
            
            // 5. Wait the configured skip speed
            await sleep(reelsSkipSpeed);
            
            // 6. Skip to next reel
            if (reelsSkipperRunning) {
                skipToNextReel();
                
                // Wait for navigation to complete
                await sleep(500);
            }
            
            // 7. Continue loop
            if (reelsSkipperRunning) {
                requestAnimationFrame(() => reelsSkipperLoop());
            }
        } catch (e) {
            console.error('[AdNull] Skipper error:', e);
            if (reelsSkipperRunning) {
                setTimeout(() => reelsSkipperLoop(), 1000);
            }
        }
    }
    
    function getCurrentVideoId() {
        // Find the currently visible video container
        for (const container of document.querySelectorAll('[data-video-id]')) {
            const rect = container.getBoundingClientRect();
            // Check if video is in the center of viewport
            const centerY = window.innerHeight / 2;
            if (rect.top < centerY && rect.bottom > centerY) {
                return container.getAttribute('data-video-id');
            }
        }
        return null;
    }
    
    async function waitForCurrentReel() {
        // Wait up to 3 seconds for a video to become visible
        for (let i = 0; i < 30; i++) {
            const video = document.querySelector('video');
            if (video && video.readyState >= 2) return;
            await sleep(100);
        }
    }
    
    function startReelsSkipper() {
        if (reelsSkipperRunning) return; // Already running
        
        reelsSkipperRunning = true;
        lastScannedVideoId = null;
        
        console.log(`[AdNull] Reels skipper started (${reelsSkipSpeed}ms, method: ${reelsSkipMethod}, scan-first mode)`);
        updateReelsSkipperUI(true);
        
        // Start the scan-first loop
        reelsSkipperLoop();
    }
    
    function stopReelsSkipper() {
        if (!reelsSkipperRunning) return;
        
        reelsSkipperRunning = false;
        lastScannedVideoId = null;
        
        // Also clear legacy interval if any
        if (reelsSkipperInterval) {
            clearInterval(reelsSkipperInterval);
            reelsSkipperInterval = null;
        }
        
        console.log('[AdNull] Reels skipper stopped');
        updateReelsSkipperUI(false);
    }
    
    function restartReelsSkipper() {
        if (reelsSkipperRunning) {
            console.log(`[AdNull] Reels skipper speed updated to ${reelsSkipSpeed}ms`);
            // Speed will be used in next iteration automatically
        }
    }
    
    function updateReelsSkipperUI(active) {
        const startBtn = document.getElementById('btn-reels-start');
        const stopBtn = document.getElementById('btn-reels-stop');
        const section = document.getElementById('reels-section');
        
        if (startBtn) startBtn.classList.toggle('hidden', active);
        if (stopBtn) stopBtn.classList.toggle('hidden', !active);
        if (section) section.classList.toggle('active', active);
    }

    // ══════════════════════════════════════════════════════════════════════
    // BLOCKING SEQUENCE (for blocking tabs only)
    // ══════════════════════════════════════════════════════════════════════
    function isPageUnavailable() {
        const text = document.body?.innerText || '';
        const patterns = [
            /this content isn't available/i,
            /this page isn't available/i,
            /this account has been disabled/i,
            /sorry, this content isn't available/i,
            /the link you followed may be broken/i,
            /page not found/i,
            /content not found/i
        ];
        for (const p of patterns) if (p.test(text)) return true;
        if (document.querySelector('a[aria-label="Go to Feed"]')) return true;
        return false;
    }
    
    function findMenuButton() {
        for (const el of document.querySelectorAll('div[role="button"][aria-haspopup="menu"]')) {
            const label = (el.getAttribute('aria-label') || '').toLowerCase();
            if (label.includes('profile') || label.includes('more') || label.includes('options') || label.includes('settings')) {
                if (isVisible(el)) return el;
            }
        }
        return null;
    }
    
    function findBlockMenuItem() {
        for (const menu of document.querySelectorAll('div[role="menu"], div[role="listbox"]')) {
            for (const item of menu.querySelectorAll('[role="menuitem"], [role="option"]')) {
                if (/^block/i.test(item.textContent?.trim() || '')) {
                    if (isVisible(item)) return item;
                }
            }
        }
        return null;
    }
    
    function findBlockDialog() {
        for (const d of document.querySelectorAll('[role="dialog"]')) {
            if (isVisible(d) && /block/i.test(d.textContent)) return d;
        }
        return null;
    }
    
    function findButton(container, label) {
        let btn = container.querySelector(`[role="button"][aria-label="${label}"]`);
        if (btn && isVisible(btn)) return btn;
        for (const el of container.querySelectorAll('[role="button"], button')) {
            if (el.textContent?.trim() === label && isVisible(el)) return el;
        }
        return null;
    }
    
    async function executeBlockSequence(config = {}) {
        const clickDelay = config.clickDelay || 400;
        
        try {
            // Find and click the menu button (3-dot menu)
            const menuBtn = await waitFor(findMenuButton, 200, 100);  // 20 seconds max
            menuBtn.click();
            await sleep(clickDelay);
            
            // Find and click "Block" in the menu
            const blockItem = await waitFor(findBlockMenuItem, 150, 100);  // 15 seconds max
            blockItem.click();
            await sleep(clickDelay);
            
            // Find the confirmation dialog
            const dialog = await waitFor(findBlockDialog, 150, 100);  // 15 seconds max
            const confirmBtn = await waitFor(() => findButton(dialog, 'Confirm'), 100, 100);  // 10 seconds max
            confirmBtn.click();
            await sleep(clickDelay * 2);
            
            // Wait for success message
            const successDialog = await waitFor(() => {
                for (const d of document.querySelectorAll('[role="dialog"]')) {
                    if (isVisible(d) && /you blocked|has been blocked/i.test(d.textContent)) return d;
                }
                return null;
            }, 100, 100);  // 10 seconds max
            
            // Close the success dialog
            const closeBtn = await waitFor(() => findButton(successDialog, 'Close'), 50, 100);  // 5 seconds max
            closeBtn.click();
            
            return { success: true };
        } catch (e) {
            return { success: false, error: e.message };
        }
    }
    
    async function runBlockingTab() {
        console.log('[AdNull] === BLOCKING TAB MODE ===');
        
        // Create overlay immediately
        const overlay = document.createElement('div');
        overlay.id = 'adnull-overlay';
        overlay.innerHTML = `
            <div class="overlay-box">
                <div class="overlay-icon">🚫</div>
                <div class="overlay-status" id="block-status">Loading...</div>
                <div class="overlay-progress"><div class="progress-bar" id="progress-bar"></div></div>
            </div>
        `;
        document.body.appendChild(overlay);
        
        const setStatus = (text, pct) => {
            const s = document.getElementById('block-status');
            const p = document.getElementById('progress-bar');
            if (s) s.textContent = text;
            if (p) p.style.width = pct + '%';
        };
        
        // Check IMMEDIATELY if page is unavailable (already blocked)
        // First quick check
        await sleep(300);
        if (isPageUnavailable()) {
            console.log('[AdNull] Page unavailable - FAST CLOSE');
            setStatus('✓ Already Blocked', 100);
            document.querySelector('.overlay-box')?.classList.add('success');
            chrome.runtime.sendMessage({ action: 'pageUnavailable' });
            return;
        }
        
        // Tell background we're ready to execute
        chrome.runtime.sendMessage({ action: 'blockTabReady' });
    }
    
    async function handleExecuteBlock(config = {}) {
        const setStatus = (text, pct) => {
            const s = document.getElementById('block-status');
            const p = document.getElementById('progress-bar');
            if (s) s.textContent = text;
            if (p) p.style.width = pct + '%';
        };
        
        setStatus('Loading page...', 20);
        await sleep(config.pageLoadWait || 1000);
        
        // Double check for unavailable
        if (isPageUnavailable()) {
            console.log('[AdNull] Page unavailable after wait');
            setStatus('✓ Already Blocked', 100);
            document.querySelector('.overlay-box')?.classList.add('success');
            chrome.runtime.sendMessage({ action: 'blockResult', result: { success: false, alreadyBlocked: true } });
            return;
        }
        
        setStatus('Blocking...', 50);
        const result = await executeBlockSequence(config);
        
        if (result.success) {
            setStatus('✓ BLOCKED!', 100);
            document.querySelector('.overlay-icon').textContent = '✓';
            document.querySelector('.overlay-box')?.classList.add('success');
        } else {
            setStatus('✗ ' + (result.error || 'Failed'), 100);
            document.querySelector('.overlay-icon').textContent = '✗';
            document.querySelector('.overlay-box')?.classList.add('failed');
        }
        
        chrome.runtime.sendMessage({ action: 'blockResult', result });
    }
    
    // ══════════════════════════════════════════════════════════════════════
    // TOAST & SCROLL
    // ══════════════════════════════════════════════════════════════════════
    function showToast(message, type = 'info') {
        document.querySelectorAll('.adnull-toast').forEach(t => t.remove());
        const toast = document.createElement('div');
        toast.className = `adnull-toast ${type}`;
        const icons = { success: '✓', error: '✗', warning: '⚠', info: 'ℹ' };
        toast.innerHTML = `<span class="toast-icon">${icons[type] || 'ℹ'}</span><span>${message}</span>`;
        document.body.appendChild(toast);
        setTimeout(() => toast.classList.add('visible'), 10);
        setTimeout(() => { toast.classList.remove('visible'); setTimeout(() => toast.remove(), 300); }, 3000);
    }
    
    function scroll(amount) {
        window.scrollBy({ top: amount, behavior: 'smooth' });
    }

    // ══════════════════════════════════════════════════════════════════════
    // DASHBOARD
    // ══════════════════════════════════════════════════════════════════════
    function createDashboard() {
        // Remove existing if any
        const existing = document.getElementById('adnull-dash');
        if (existing) existing.remove();
        
        console.log('[AdNull] Creating dashboard...');
        
        const dash = document.createElement('div');
        dash.id = 'adnull-dash';
        dash.className = 'locked';
        dash.innerHTML = `
            <div class="dash-handle"><span>≡</span></div>
            <div class="dash-main">
                <div class="dash-header">
                    <div class="dash-title">
                        <span class="logo">🚫</span>
                        <span class="name">AdNull Pro</span>
                        <span class="ver">v${VERSION}</span>
                    </div>
                    <div class="header-btns">
                        <button class="icon-btn" id="lock-btn" title="Lock">🔒</button>
                        <button class="icon-btn" id="settings-btn" title="Settings">⚙️</button>
                    </div>
                </div>
                
                <div class="dash-body">
                    <!-- Page State -->
                    <div class="page-state">
                        <span class="page-icon" id="page-icon">${getPageIcon()}</span>
                        <span class="page-type" id="page-type">${getPageLabel()}</span>
                        <span class="platform">Facebook</span>
                    </div>
                    
                    <!-- Status -->
                    <div class="status-bar">
                        <span class="status-dot" id="status-dot"></span>
                        <span class="status-text" id="status-text">Ready</span>
                    </div>
                    
                    <!-- Stats -->
                    <div class="section" data-section="stats">
                        <div class="section-head"><span>📊 Stats</span><span class="caret">▼</span></div>
                        <div class="section-body">
                            <div class="stats">
                                <div class="stat"><div class="val" id="s-blocked">0</div><div class="lbl">Blocked</div></div>
                                <div class="stat"><div class="val" id="s-session">0</div><div class="lbl">Session</div></div>
                                <div class="stat accent"><div class="val" id="s-queue">0</div><div class="lbl">Queue</div></div>
                                <div class="stat fail"><div class="val" id="s-failed">0</div><div class="lbl">Failed</div></div>
                            </div>
                            <button class="retry-btn hidden" id="btn-retry-all">🔄 Retry All Failed</button>
                        </div>
                    </div>
                    
                    <!-- Speed (Feed only) -->
                    <div class="section feed-only ${getPageType() === 'reels' ? 'hidden' : ''}" id="speed-section" data-section="speed">
                        <div class="section-head"><span>⚡ Speed</span><span class="caret">▼</span></div>
                        <div class="section-body">
                            <div class="speed-btns">
                                <button class="speed-btn" data-speed="careful" title="Careful">🐢</button>
                                <button class="speed-btn active" data-speed="normal" title="Normal">🚶</button>
                                <button class="speed-btn" data-speed="fast" title="Fast">🏃</button>
                                <button class="speed-btn" data-speed="turbo" title="Turbo">🚀</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Controls -->
                    <div class="section" data-section="controls">
                        <div class="section-head"><span>🎯 Controls</span><span class="caret">▼</span></div>
                        <div class="section-body">
                            <div class="control-btns">
                                <button class="ctrl-btn primary" id="btn-start">▶ Start</button>
                                <button class="ctrl-btn danger hidden" id="btn-stop">⏹ Stop</button>
                                <button class="ctrl-btn secondary" id="btn-pause">⏸</button>
                            </div>
                            <div class="current-item hidden" id="current-item">
                                <span class="ci-label">Blocking:</span>
                                <span class="ci-name" id="current-name">-</span>
                                <button class="ci-skip" id="btn-skip">Skip</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Reels Skipper (Reels only) -->
                    <div class="section reels-section reels-only ${getPageType() === 'reels' ? '' : 'hidden'}" id="reels-section" data-section="reels">
                        <div class="section-head"><span>🎬 Reels Skipper</span><span class="caret">▼</span></div>
                        <div class="section-body">
                            <div class="reels-info">Scan → Collect → Batch Block → Refresh</div>
                            <div class="batch-status" id="batch-status">
                                <span class="batch-progress">Queue: <span id="batch-queue">0</span>/<span id="batch-size-display">10</span></span>
                                <span class="batch-indicator" id="batch-indicator"></span>
                            </div>
                            <div class="reels-btns">
                                <button class="ctrl-btn primary" id="btn-reels-start">▶ Start Scan & Skip</button>
                                <button class="ctrl-btn danger hidden" id="btn-reels-stop">⏹ Stop</button>
                            </div>
                            <div class="reels-settings">
                                <div class="reels-setting">
                                    <label>Batch Size:</label>
                                    <div class="batch-size-input">
                                        <input type="number" id="batch-size" min="1" max="500" value="10" step="1">
                                        <button class="set-btn small" id="btn-set-batch">Set</button>
                                    </div>
                                </div>
                                <div class="reels-setting">
                                    <label>Speed: <span id="reels-speed-val">2.0s</span></label>
                                    <input type="range" id="reels-speed" min="500" max="5000" step="250" value="2000">
                                </div>
                                <div class="reels-setting">
                                    <label>Method:</label>
                                    <div class="method-toggle">
                                        <button class="method-btn active" data-method="button" title="Click the Next button">🔘 Button</button>
                                        <button class="method-btn" data-method="keyboard" title="Simulate keyboard">⌨️ Key</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Activity Log -->
                    <div class="section" data-section="log">
                        <div class="section-head">
                            <span>📜 Activity (<span id="log-count">0</span>)</span>
                            <span class="caret">▼</span>
                        </div>
                        <div class="section-body">
                            <div class="log-wrapper" id="log-wrapper">
                                <table class="log-table">
                                    <thead><tr><th>Name</th><th>Source</th><th>Status</th></tr></thead>
                                    <tbody id="log-tbody"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Settings Panel -->
                <div class="panel" id="settings-panel">
                    <div class="panel-head">
                        <span>⚙️ Settings</span>
                        <button class="close-btn" id="close-settings">✕</button>
                    </div>
                    <div class="panel-body">
                        <div class="tabs">
                            <button class="tab active" data-tab="general">General</button>
                            <button class="tab" data-tab="timing">Timing</button>
                            <button class="tab" data-tab="data">Data</button>
                            <button class="tab" data-tab="github">GitHub</button>
                        </div>
                        
                        <div class="tab-content active" data-tab="general">
                            <label class="opt"><input type="checkbox" id="opt-autostart" checked><span>Auto-start</span></label>
                            <label class="opt"><input type="checkbox" id="opt-scroll" checked><span>Auto-scroll feed</span></label>
                            <label class="opt"><input type="checkbox" id="opt-skip-reels" checked><span>Skip sponsored reels</span></label>
                            <label class="opt"><input type="checkbox" id="opt-notifs" checked><span>Notifications</span></label>
                            <label class="opt"><input type="checkbox" id="opt-buttons" checked><span>Block buttons</span></label>
                            <label class="opt"><input type="checkbox" id="opt-foundation" checked><span>Auto-import foundation</span></label>
                            <label class="opt" title="Uses popup windows for blocking"><input type="checkbox" id="opt-popup-window" checked><span>Popup window mode</span></label>
                            <label class="opt" title="Focus blocking window to prevent timeouts (recommended)"><input type="checkbox" id="opt-focus-blocking" checked><span>Focus while blocking 🎯</span></label>
                            <button class="set-btn" id="btn-reimport">🔄 Re-import Foundation</button>
                        </div>
                        
                        <div class="tab-content" data-tab="timing">
                            <p class="timing-tip">⚡ Lower = Faster but less reliable | Higher = Slower but more reliable</p>
                            
                            <div class="slider-group">
                                <label>Wait between blocks <span id="v-block">600ms</span></label>
                                <p class="slider-desc">Time to wait before starting the next block. Increase if blocks are failing.</p>
                                <input type="range" id="r-block" min="100" max="2000" step="100" value="600">
                            </div>
                            <div class="slider-group">
                                <label>Wait for page to load <span id="v-page">1000ms</span></label>
                                <p class="slider-desc">How long to wait for the profile page to fully load. Increase if you get timeouts.</p>
                                <input type="range" id="r-page" min="500" max="5000" step="250" value="1000">
                            </div>
                            <div class="slider-group">
                                <label>Wait between clicks <span id="v-click">300ms</span></label>
                                <p class="slider-desc">Time between clicking menu items. Increase if menus aren't opening properly.</p>
                                <input type="range" id="r-click" min="100" max="1000" step="50" value="300">
                            </div>
                            <div class="slider-group">
                                <label>Wait before closing window <span id="v-close">500ms</span></label>
                                <p class="slider-desc">Time to wait after blocking before closing. Increase to see the result longer.</p>
                                <input type="range" id="r-close" min="100" max="2000" step="100" value="500">
                            </div>
                            <div class="slider-group">
                                <label>Time between scrolls <span id="v-scroll">2500ms</span></label>
                                <p class="slider-desc">How often to scroll the feed when scanning. Slower = more thorough scanning.</p>
                                <input type="range" id="r-scroll" min="1000" max="8000" step="500" value="2500">
                            </div>
                            <button class="set-btn secondary" id="btn-reset-timing">Reset to Defaults</button>
                        </div>
                        
                        <div class="tab-content" data-tab="data">
                            <div class="data-section">
                                <h4>📋 Queue</h4>
                                <button class="set-btn" id="btn-view-queue">View Queue</button>
                                <button class="set-btn danger-outline" id="btn-clear-queue">Clear Queue</button>
                                <button class="set-btn" id="btn-retry-failed">Retry Failed</button>
                            </div>
                            <div class="data-section">
                                <h4>🔄 Reprocess</h4>
                                <p class="data-desc">Re-verify all entries are blocked</p>
                                <button class="set-btn warning" id="btn-reprocess-all">Reprocess All Entries</button>
                            </div>
                            <div class="data-section">
                                <h4>✅ Whitelist</h4>
                                <div class="whitelist-add">
                                    <input type="text" id="wl-input" placeholder="Profile URL">
                                    <button class="set-btn small" id="btn-add-wl">Add</button>
                                </div>
                                <div class="whitelist-list" id="wl-list"></div>
                            </div>
                            <div class="data-section">
                                <h4>📤 Import/Export</h4>
                                <button class="set-btn" id="btn-export">Export CSV</button>
                                <button class="set-btn" id="btn-import">Import</button>
                                <input type="file" id="import-file" accept=".csv" style="display:none">
                            </div>
                            <div class="data-section danger">
                                <h4>⚠️ Danger</h4>
                                <button class="set-btn danger" id="btn-clear-all">Clear All Data</button>
                            </div>
                        </div>
                        
                        <div class="tab-content" data-tab="github">
                            <div class="github-header">
                                <span>🐙 Auto-sync blocklist to GitHub</span>
                            </div>
                            <label class="opt"><input type="checkbox" id="opt-github-sync"><span>Enable GitHub Sync</span></label>
                            <div class="github-form" id="github-form">
                                <div class="input-group">
                                    <label>Personal Access Token</label>
                                    <input type="password" id="gh-token" placeholder="ghp_xxxxxxxxxxxx">
                                    <small>Needs 'repo' scope. <a href="https://github.com/settings/tokens/new?scopes=repo" target="_blank">Create token</a></small>
                                </div>
                                <div class="input-group">
                                    <label>Repository</label>
                                    <input type="text" id="gh-repo" placeholder="username/repo">
                                </div>
                                <div class="input-group">
                                    <label>File Path</label>
                                    <input type="text" id="gh-path" placeholder="blocklists/facebook.csv">
                                </div>
                                <div class="input-group">
                                    <label>Branch</label>
                                    <input type="text" id="gh-branch" placeholder="main" value="main">
                                </div>
                                <div class="github-btns">
                                    <button class="set-btn" id="btn-gh-test">🔌 Test</button>
                                    <button class="set-btn primary" id="btn-gh-save">💾 Save</button>
                                    <button class="set-btn" id="btn-gh-sync-now">📤 Sync Now</button>
                                </div>
                                <div class="github-status" id="gh-status"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Queue Panel -->
                <div class="panel" id="queue-panel">
                    <div class="panel-head">
                        <span>📋 Queue (<span id="q-count">0</span>)</span>
                        <button class="close-btn" id="close-queue">✕</button>
                    </div>
                    <div class="panel-body">
                        <div class="queue-list" id="queue-list"></div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(dash);
        dashboardReady = true;
        
        setupDashboardEvents();
        console.log('[AdNull] Dashboard created successfully');
        
        return dash;
    }

    function setupDashboardEvents() {
        const dash = document.getElementById('adnull-dash');
        if (!dash) return;
        
        // Lock/Unlock
        document.getElementById('lock-btn').onclick = () => {
            const locked = dash.classList.toggle('locked');
            dash.classList.toggle('unlocked', !locked);
            document.getElementById('lock-btn').textContent = locked ? '🔒' : '🔓';
            chrome.runtime.sendMessage({ action: 'setDashboardLocked', locked });
        };
        
        // Settings panel
        document.getElementById('settings-btn').onclick = () => {
            document.getElementById('settings-panel').classList.add('open');
        };
        document.getElementById('close-settings').onclick = () => {
            document.getElementById('settings-panel').classList.remove('open');
        };
        
        // Section collapse
        dash.querySelectorAll('.section-head').forEach(head => {
            head.onclick = () => {
                const section = head.closest('.section');
                const collapsed = section.classList.toggle('collapsed');
                head.querySelector('.caret').textContent = collapsed ? '▶' : '▼';
                chrome.runtime.sendMessage({ action: 'setSectionCollapsed', section: section.dataset.section, collapsed });
            };
        });
        
        // Speed presets
        dash.querySelectorAll('.speed-btn').forEach(btn => {
            btn.onclick = () => {
                dash.querySelectorAll('.speed-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                chrome.runtime.sendMessage({ action: 'setSpeedPreset', preset: btn.dataset.speed });
            };
        });
        
        // Controls
        document.getElementById('btn-start').onclick = () => chrome.runtime.sendMessage({ action: 'start' });
        document.getElementById('btn-stop').onclick = () => chrome.runtime.sendMessage({ action: 'stop' });
        document.getElementById('btn-pause').onclick = () => {
            chrome.runtime.sendMessage({ action: state?.isPaused ? 'resume' : 'pause' });
        };
        document.getElementById('btn-skip')?.addEventListener('click', () => {
            chrome.runtime.sendMessage({ action: 'skipCurrentBlock' });
        });
        
        // Retry all failed button
        document.getElementById('btn-retry-all')?.addEventListener('click', () => {
            chrome.runtime.sendMessage({ action: 'retryAllFailed' }, r => {
                if (r?.requeued > 0) {
                    showToast(`Requeued ${r.requeued} failed items`, 'success');
                } else {
                    showToast('No failed items to retry', 'info');
                }
            });
        });
        
        // Reels skipper
        document.getElementById('btn-reels-start').onclick = () => {
            startReelsSkipper();
            chrome.runtime.sendMessage({ action: 'setReelsSkipper', active: true });
        };
        document.getElementById('btn-reels-stop').onclick = () => {
            stopReelsSkipper();
            chrome.runtime.sendMessage({ action: 'setReelsSkipper', active: false });
        };
        
        // Reels speed slider
        const speedSlider = document.getElementById('reels-speed');
        const speedVal = document.getElementById('reels-speed-val');
        if (speedSlider) {
            speedSlider.oninput = () => {
                const val = parseInt(speedSlider.value);
                speedVal.textContent = (val / 1000).toFixed(1) + 's';
            };
            speedSlider.onchange = () => {
                reelsSkipSpeed = parseInt(speedSlider.value);
                restartReelsSkipper(); // Apply new speed if running
            };
        }
        
        // Reels method toggle
        dash.querySelectorAll('.method-btn').forEach(btn => {
            btn.onclick = () => {
                dash.querySelectorAll('.method-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                reelsSkipMethod = btn.dataset.method;
                console.log('[AdNull] Reels method changed to:', reelsSkipMethod);
            };
        });
        
        // Batch size setting
        document.getElementById('btn-set-batch')?.addEventListener('click', () => {
            const input = document.getElementById('batch-size');
            const size = parseInt(input?.value) || 10;
            const clampedSize = Math.max(1, Math.min(500, size));
            input.value = clampedSize;
            
            chrome.runtime.sendMessage({ action: 'setReelsBatchSize', size: clampedSize }, r => {
                if (r?.success) {
                    showToast(`Batch size set to ${clampedSize}`, 'success');
                    document.getElementById('batch-size-display').textContent = clampedSize;
                }
            });
        });
        
        // Also update on Enter key
        document.getElementById('batch-size')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                document.getElementById('btn-set-batch')?.click();
            }
        });
        
        // Tabs
        dash.querySelectorAll('.tab').forEach(tab => {
            tab.onclick = () => {
                dash.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                dash.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                tab.classList.add('active');
                dash.querySelector(`.tab-content[data-tab="${tab.dataset.tab}"]`).classList.add('active');
            };
        });
        
        // General settings
        const checkboxes = {
            'opt-autostart': 'autoStart',
            'opt-scroll': 'scrollEnabled',
            'opt-skip-reels': 'skipSponsoredReels',
            'opt-notifs': 'showNotifications',
            'opt-buttons': 'showBlockButtons',
            'opt-foundation': 'autoImportFoundation',
            'opt-popup-window': 'usePopupWindow',
            'opt-focus-blocking': 'focusBlockingTab'
        };
        Object.entries(checkboxes).forEach(([id, key]) => {
            document.getElementById(id).onchange = (e) => {
                chrome.runtime.sendMessage({ action: 'setConfig', config: { [key]: e.target.checked } });
            };
        });
        
        // Timing sliders
        const sliders = {
            'r-block': { key: 'blockDelay', display: 'v-block' },
            'r-page': { key: 'pageLoadWait', display: 'v-page' },
            'r-click': { key: 'clickDelay', display: 'v-click' },
            'r-close': { key: 'tabCloseDelay', display: 'v-close' },
            'r-scroll': { key: 'scrollDelay', display: 'v-scroll' }
        };
        Object.entries(sliders).forEach(([id, { key, display }]) => {
            const slider = document.getElementById(id);
            const disp = document.getElementById(display);
            slider.oninput = () => { disp.textContent = slider.value + 'ms'; };
            slider.onchange = () => {
                chrome.runtime.sendMessage({ action: 'setConfig', config: { [key]: parseInt(slider.value) } });
            };
        });
        
        document.getElementById('btn-reset-timing').onclick = () => {
            chrome.runtime.sendMessage({ action: 'resetConfig' });
            showToast('Reset to defaults', 'success');
        };
        
        document.getElementById('btn-reimport').onclick = () => {
            chrome.runtime.sendMessage({ action: 'importFoundation', force: true });
            showToast('Importing...', 'info');
        };
        
        // Queue
        document.getElementById('btn-view-queue').onclick = () => {
            document.getElementById('queue-panel').classList.add('open');
            document.getElementById('settings-panel').classList.remove('open');
        };
        document.getElementById('close-queue').onclick = () => {
            document.getElementById('queue-panel').classList.remove('open');
        };
        document.getElementById('btn-clear-queue').onclick = () => {
            if (confirm('Clear queue?')) chrome.runtime.sendMessage({ action: 'clearQueue' });
        };
        document.getElementById('btn-retry-failed').onclick = () => {
            chrome.runtime.sendMessage({ action: 'requeueFailed' }, r => {
                if (r?.requeued) showToast(`Requeued ${r.requeued}`, 'success');
                else showToast('No failed items', 'info');
            });
        };
        
        // Reprocess all
        document.getElementById('btn-reprocess-all').onclick = () => {
            if (!confirm('This will re-queue ALL entries to verify they are blocked. Continue?')) return;
            chrome.runtime.sendMessage({ action: 'reprocessAll' }, r => {
                if (r?.requeued) showToast(`Queued ${r.requeued} for reprocessing`, 'success');
                else showToast('No entries to reprocess', 'info');
            });
        };
        
        // Whitelist
        document.getElementById('btn-add-wl').onclick = () => {
            let url = document.getElementById('wl-input').value.trim();
            if (!url) return;
            if (!url.includes('facebook.com')) url = `https://www.facebook.com/${url}`;
            chrome.runtime.sendMessage({ action: 'addToWhitelist', url, name: url.split('/').pop() }, r => {
                if (r?.added) { showToast('Added', 'success'); document.getElementById('wl-input').value = ''; }
            });
        };
        
        // Import/Export
        document.getElementById('btn-export').onclick = () => {
            chrome.runtime.sendMessage({ action: 'exportData' }, r => { if (r?.data) downloadCSV(r.data.masterLog); });
        };
        document.getElementById('btn-import').onclick = () => document.getElementById('import-file').click();
        document.getElementById('import-file').onchange = function() {
            if (this.files.length) { importCSV(this.files[0]); this.value = ''; }
        };
        
        // Clear all
        document.getElementById('btn-clear-all').onclick = () => {
            if (confirm('Delete ALL data?')) {
                chrome.runtime.sendMessage({ action: 'clearAllData' });
                showToast('Cleared', 'success');
            }
        };
        
        // GitHub Sync
        const ghSyncToggle = document.getElementById('opt-github-sync');
        const ghForm = document.getElementById('github-form');
        const ghStatus = document.getElementById('gh-status');
        
        ghSyncToggle?.addEventListener('change', () => {
            chrome.runtime.sendMessage({ 
                action: 'setGitHubConfig', 
                enabled: ghSyncToggle.checked 
            });
        });
        
        document.getElementById('btn-gh-test')?.addEventListener('click', () => {
            ghStatus.textContent = 'Testing...';
            ghStatus.className = 'github-status testing';
            chrome.runtime.sendMessage({ action: 'testGitHub' }, r => {
                if (r?.success) {
                    ghStatus.textContent = `✓ Connected to ${r.repoName}`;
                    ghStatus.className = 'github-status success';
                } else {
                    ghStatus.textContent = `✗ ${r?.error || 'Failed'}`;
                    ghStatus.className = 'github-status error';
                }
            });
        });
        
        document.getElementById('btn-gh-save')?.addEventListener('click', () => {
            const config = {
                action: 'setGitHubConfig',
                token: document.getElementById('gh-token')?.value || '',
                repo: document.getElementById('gh-repo')?.value || '',
                path: document.getElementById('gh-path')?.value || '',
                branch: document.getElementById('gh-branch')?.value || 'main'
            };
            chrome.runtime.sendMessage(config, r => {
                if (r?.success) {
                    showToast('GitHub settings saved', 'success');
                    ghStatus.textContent = '✓ Settings saved';
                    ghStatus.className = 'github-status success';
                }
            });
        });
        
        document.getElementById('btn-gh-sync-now')?.addEventListener('click', () => {
            ghStatus.textContent = 'Syncing...';
            ghStatus.className = 'github-status testing';
            chrome.runtime.sendMessage({ action: 'syncToGitHub' }, r => {
                if (r?.success) {
                    ghStatus.textContent = `✓ Synced! Commit: ${r.commit?.substring(0, 7)}`;
                    ghStatus.className = 'github-status success';
                    showToast('GitHub sync complete!', 'success');
                } else {
                    ghStatus.textContent = `✗ ${r?.error || 'Failed'}`;
                    ghStatus.className = 'github-status error';
                    showToast(`Sync failed: ${r?.error}`, 'error');
                }
            });
        });
        
        // Draggable
        makeDraggable(dash);
    }
    
    function makeDraggable(el) {
        const header = el.querySelector('.dash-header');
        let dragging = false, startX, startY, startLeft, startTop;
        
        header.onmousedown = (e) => {
            if (e.target.classList.contains('icon-btn') || el.classList.contains('unlocked')) return;
            dragging = true;
            startX = e.clientX; startY = e.clientY;
            const rect = el.getBoundingClientRect();
            startLeft = rect.left; startTop = rect.top;
            el.style.transition = 'none';
        };
        
        document.onmousemove = (e) => {
            if (!dragging) return;
            el.style.left = (startLeft + e.clientX - startX) + 'px';
            el.style.top = (startTop + e.clientY - startY) + 'px';
            el.style.right = 'auto';
        };
        
        document.onmouseup = () => { if (dragging) { dragging = false; el.style.transition = ''; } };
    }
    
    function updatePageState() {
        const icon = document.getElementById('page-icon');
        const type = document.getElementById('page-type');
        const reelsSection = document.getElementById('reels-section');
        const speedSection = document.getElementById('speed-section');
        
        const pageType = getPageType();
        const isReels = pageType === 'reels';
        
        if (icon) icon.textContent = getPageIcon();
        if (type) type.textContent = getPageLabel();
        
        // Toggle sections based on page type
        if (reelsSection) {
            reelsSection.classList.toggle('hidden', !isReels);
        }
        if (speedSection) {
            speedSection.classList.toggle('hidden', isReels);
        }
        
        // Stop skipper if navigating away from reels
        if (!isReels && reelsSkipperRunning) {
            stopReelsSkipper();
        }
    }

    function updateDashboard(s) {
        state = s;
        if (!dashboardReady) return;
        
        // Stats
        const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
        setVal('s-blocked', s.totalBlocked || 0);
        setVal('s-session', s.sessionDetected || 0);
        setVal('s-queue', s.queueLength || 0);
        setVal('s-failed', s.failedCount || 0);
        setVal('log-count', s.logLength || 0);
        setVal('q-count', s.queueLength || 0);
        setVal('batch-queue', s.queueLength || 0);
        
        // Update batch size display
        const batchSize = s.reelsBatchSize || 10;
        setVal('batch-size-display', batchSize);
        const batchInput = document.getElementById('batch-size');
        if (batchInput && !batchInput.matches(':focus')) {
            batchInput.value = batchSize;
        }
        
        // Show/hide retry button based on failed count
        const retryBtn = document.getElementById('btn-retry-all');
        if (retryBtn) {
            retryBtn.classList.toggle('hidden', (s.failedCount || 0) === 0);
        }
        
        // Batch status indicator
        const batchIndicator = document.getElementById('batch-indicator');
        if (batchIndicator) {
            if (s.reelsBatchInProgress) {
                batchIndicator.textContent = '🔄 Blocking...';
                batchIndicator.className = 'batch-indicator blocking';
            } else if (s.queueLength >= batchSize) {
                batchIndicator.textContent = '⏳ Starting batch...';
                batchIndicator.className = 'batch-indicator pending';
            } else if (s.reelsSkipperActive) {
                batchIndicator.textContent = '📡 Scanning...';
                batchIndicator.className = 'batch-indicator scanning';
            } else {
                batchIndicator.textContent = '';
                batchIndicator.className = 'batch-indicator';
            }
        }
        
        // Control buttons
        const start = document.getElementById('btn-start');
        const stop = document.getElementById('btn-stop');
        const pause = document.getElementById('btn-pause');
        if (start) start.classList.toggle('hidden', s.isRunning);
        if (stop) stop.classList.toggle('hidden', !s.isRunning);
        if (pause) pause.textContent = s.isPaused ? '▶' : '⏸';
        
        // Current item
        const ci = document.getElementById('current-item');
        if (ci) {
            ci.classList.toggle('hidden', !s.currentBlockItem);
            if (s.currentBlockItem) document.getElementById('current-name').textContent = s.currentBlockItem.author;
        }
        
        // Status
        const dot = document.getElementById('status-dot');
        const text = document.getElementById('status-text');
        if (dot && text) {
            if (s.reelsBatchInProgress) { dot.className = 'status-dot blocking'; text.textContent = 'Batch blocking...'; }
            else if (s.isBlocking) { dot.className = 'status-dot blocking'; text.textContent = 'Blocking: ' + (s.currentBlockItem?.author || '...'); }
            else if (s.isPaused) { dot.className = 'status-dot paused'; text.textContent = 'Paused'; }
            else if (s.isRunning) { dot.className = 'status-dot running'; text.textContent = 'Scanning...'; }
            else { dot.className = 'status-dot'; text.textContent = 'Ready'; }
        }
        
        // Speed preset
        if (s.speedPreset) {
            document.querySelectorAll('.speed-btn').forEach(b => b.classList.toggle('active', b.dataset.speed === s.speedPreset));
        }
        
        // Lock state
        const dash = document.getElementById('adnull-dash');
        if (dash && s.config?.dashboardLocked !== undefined) {
            dash.classList.toggle('locked', s.config.dashboardLocked);
            dash.classList.toggle('unlocked', !s.config.dashboardLocked);
            const lb = document.getElementById('lock-btn');
            if (lb) lb.textContent = s.config.dashboardLocked ? '🔒' : '🔓';
        }
        
        // Settings values
        if (s.config) {
            const c = s.config;
            document.getElementById('opt-autostart').checked = c.autoStart;
            document.getElementById('opt-scroll').checked = c.scrollEnabled;
            document.getElementById('opt-skip-reels').checked = c.skipSponsoredReels;
            document.getElementById('opt-notifs').checked = c.showNotifications;
            document.getElementById('opt-buttons').checked = c.showBlockButtons;
            document.getElementById('opt-foundation').checked = c.autoImportFoundation;
            
            // Popup window mode
            const popupOpt = document.getElementById('opt-popup-window');
            if (popupOpt) popupOpt.checked = c.usePopupWindow !== false; // default true
            
            // Focus blocking mode
            const focusOpt = document.getElementById('opt-focus-blocking');
            if (focusOpt) focusOpt.checked = c.focusBlockingTab !== false; // default true
            
            // GitHub config
            const ghSync = document.getElementById('opt-github-sync');
            if (ghSync) ghSync.checked = c.githubSyncEnabled;
            if (c.githubToken) document.getElementById('gh-token').value = c.githubToken;
            if (c.githubRepo) document.getElementById('gh-repo').value = c.githubRepo;
            if (c.githubPath) document.getElementById('gh-path').value = c.githubPath;
            if (c.githubBranch) document.getElementById('gh-branch').value = c.githubBranch || 'main';
            
            const setSlider = (id, val, dispId) => {
                const s = document.getElementById(id);
                const d = document.getElementById(dispId);
                if (s) s.value = val;
                if (d) d.textContent = val + 'ms';
            };
            setSlider('r-block', c.blockDelay, 'v-block');
            setSlider('r-page', c.pageLoadWait, 'v-page');
            setSlider('r-click', c.clickDelay, 'v-click');
            setSlider('r-close', c.tabCloseDelay, 'v-close');
            setSlider('r-scroll', c.scrollDelay, 'v-scroll');
        }
        
        // Reels skipper state
        if (s.reelsSkipperActive && getPageType() === 'reels') {
            if (!reelsSkipperInterval) startReelsSkipper();
        }
        
        // Render lists
        renderWhitelist(s.whitelist || []);
        renderQueue(s.blockQueue || []);
        renderLog(s.masterLog || []);
    }
    
    function renderWhitelist(list) {
        const container = document.getElementById('wl-list');
        if (!container) return;
        if (!list.length) { container.innerHTML = '<div class="empty">No whitelist</div>'; return; }
        
        container.innerHTML = list.map(e => `
            <div class="wl-item">
                <span title="${e.url}">${e.name || e.url.split('/').pop()}</span>
                <button class="rm-btn" data-url="${e.url}">✕</button>
            </div>
        `).join('');
        
        container.querySelectorAll('.rm-btn').forEach(btn => {
            btn.onclick = () => chrome.runtime.sendMessage({ action: 'removeFromWhitelist', url: btn.dataset.url });
        });
    }
    
    function renderQueue(queue) {
        const container = document.getElementById('queue-list');
        if (!container) return;
        if (!queue.length) { container.innerHTML = '<div class="empty">Queue empty</div>'; return; }
        
        // Show ALL queue items
        container.innerHTML = queue.map((item, i) => `
            <div class="q-item ${i === 0 && state?.isBlocking ? 'active' : ''}">
                <div class="q-info">
                    <span class="q-name">${item.author}</span>
                    <span class="q-src">${item.source}</span>
                </div>
                <div class="q-actions">
                    <button class="q-btn" data-action="top" data-i="${i}" title="Move to top">⬆</button>
                    <button class="q-btn rm" data-action="rm" data-i="${i}" title="Remove">✕</button>
                </div>
            </div>
        `).join('');
        
        container.querySelectorAll('.q-btn').forEach(btn => {
            btn.onclick = () => {
                const i = parseInt(btn.dataset.i);
                if (btn.dataset.action === 'top') chrome.runtime.sendMessage({ action: 'moveToTop', index: i });
                else chrome.runtime.sendMessage({ action: 'removeFromQueue', index: i });
            };
        });
    }
    
    function renderLog(log) {
        const tbody = document.getElementById('log-tbody');
        if (!tbody) return;
        if (!log.length) { tbody.innerHTML = '<tr><td colspan="3" class="empty">No activity</td></tr>'; return; }
        
        // Render ALL entries - no limit, fully scrollable
        const icons = { detected: '🔍', queued: '📋', blocking: '🔄', blocked: '✓', failed: '✗', skipped: '↷', whitelisted: '✓', removed: '−', cleared: '−' };
        
        tbody.innerHTML = log.map(e => `
            <tr class="log-row ${e.status}" data-url="${e.url}">
                <td><a href="${e.url}" target="_blank" title="${e.url}">${e.author}</a></td>
                <td class="src">${e.source}</td>
                <td class="status">${icons[e.status] || '?'}</td>
            </tr>
        `).join('');
    }
    
    // ══════════════════════════════════════════════════════════════════════
    // IMPORT/EXPORT
    // ══════════════════════════════════════════════════════════════════════
    function downloadCSV(log) {
        const rows = [['Author', 'URL', 'Source', 'Status', 'Date']];
        log.forEach(e => rows.push([
            `"${(e.author || '').replace(/"/g, '""')}"`,
            e.url,
            e.source,
            e.status,
            new Date(e.timestamp).toISOString()
        ]));
        
        const blob = new Blob([rows.map(r => r.join(',')).join('\n')], { type: 'text/csv' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `adnull_${new Date().toISOString().slice(0,10)}.csv`;
        a.click();
        showToast(`Exported ${log.length} entries`, 'success');
    }
    
    function importCSV(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const lines = e.target.result.split('\n');
            if (lines.length < 2) {
                showToast('Empty or invalid CSV', 'error');
                return;
            }
            
            // Detect format from header
            const header = lines[0].toLowerCase();
            let authorCol = 0, urlCol = 1;
            
            // Parse header to find columns
            const headerFields = parseCSV(lines[0]);
            for (let i = 0; i < headerFields.length; i++) {
                const h = headerFields[i].toLowerCase().trim().replace(/^"|"$/g, '');
                if (h === 'name' || h === 'author') authorCol = i;
                if (h === 'url' || h === 'profile url' || h === 'profile_url') urlCol = i;
            }
            
            console.log('[AdNull] Import CSV - Author col:', authorCol, 'URL col:', urlCol);
            
            const entries = [];
            for (let i = 1; i < lines.length; i++) {
                const line = lines[i].trim();
                if (!line) continue;
                
                const fields = parseCSV(line);
                if (fields.length <= Math.max(authorCol, urlCol)) continue;
                
                const author = fields[authorCol].replace(/^"|"$/g, '').replace(/""/g, '"').trim();
                const url = fields[urlCol].replace(/^"|"$/g, '').trim();
                
                if (!url || !url.includes('facebook.com')) continue;
                
                entries.push({ 
                    url, 
                    author: author || 'Unknown',
                    source: 'import', 
                    platform: 'facebook',
                    timestamp: Date.now(), 
                    status: 'detected' 
                });
            }
            
            console.log('[AdNull] Parsed', entries.length, 'entries from CSV');
            
            if (entries.length === 0) {
                showToast('No valid entries found', 'error');
                return;
            }
            
            chrome.runtime.sendMessage({ action: 'importData', entries }, r => {
                if (r?.imported) {
                    showToast(`Imported ${r.imported} entries`, 'success');
                } else {
                    showToast('Import failed or all duplicates', 'warning');
                }
            });
        };
        reader.readAsText(file);
    }
    
    function parseCSV(line) {
        const result = []; let current = '', inQuotes = false;
        for (let i = 0; i < line.length; i++) {
            const c = line[i];
            if (c === '"') { if (inQuotes && line[i+1] === '"') { current += '"'; i++; } else inQuotes = !inQuotes; }
            else if (c === ',' && !inQuotes) { result.push(current); current = ''; }
            else current += c;
        }
        result.push(current);
        return result;
    }

    // ══════════════════════════════════════════════════════════════════════
    // MESSAGE HANDLER
    // ══════════════════════════════════════════════════════════════════════
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        console.log('[AdNull] Message received:', msg.action);
        
        switch (msg.action) {
            case 'init':
            case 'showDashboard':
                if (!isBlockingTab) {
                    if (!dashboardReady) {
                        createDashboard();
                    }
                    // Request fresh state
                    chrome.runtime.sendMessage({ action: 'getState' }, r => {
                        if (r?.state) updateDashboard(r.state);
                    });
                }
                sendResponse({ success: true, dashboardReady });
                break;
                
            case 'scan':
                const feed = scanFeed();
                const reels = scanReels();
                sendResponse({ success: true, found: feed.found + reels.found });
                break;
                
            case 'scroll':
                scroll(msg.amount);
                sendResponse({ success: true });
                break;
                
            case 'executeBlock':
                handleExecuteBlock(msg.config);
                sendResponse({ success: true });
                break;
                
            case 'stateUpdate':
                if (!dashboardReady && !isBlockingTab) {
                    createDashboard();
                }
                updateDashboard(msg.state);
                sendResponse({ success: true });
                break;
                
            case 'updateStatus':
                const dot = document.getElementById('status-dot');
                const text = document.getElementById('status-text');
                if (dot) dot.className = `status-dot ${msg.type || ''}`;
                if (text) text.textContent = msg.status;
                sendResponse({ success: true });
                break;
                
            case 'showToast':
                showToast(msg.message, msg.type);
                sendResponse({ success: true });
                break;
            
            case 'startReelsSkipper':
                if (getPageType() === 'reels') {
                    startReelsSkipper();
                }
                sendResponse({ success: true });
                break;
            
            case 'stopReelsSkipper':
                stopReelsSkipper();
                sendResponse({ success: true });
                break;
                
            default:
                sendResponse({ success: false, error: 'Unknown action' });
        }
        
        return true;
    });
    
    // ══════════════════════════════════════════════════════════════════════
    // URL CHANGE DETECTION (SPA navigation)
    // ══════════════════════════════════════════════════════════════════════
    let lastUrl = location.href;
    
    function checkUrlChange() {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            console.log('[AdNull] URL changed:', location.href.substring(0, 50));
            updatePageState();
        }
    }
    
    // Check periodically for URL changes
    setInterval(checkUrlChange, 500);
    
    // Also watch for DOM changes that might indicate navigation
    const urlObserver = new MutationObserver(checkUrlChange);
    
    // ══════════════════════════════════════════════════════════════════════
    // INITIALIZATION
    // ══════════════════════════════════════════════════════════════════════
    function init() {
        console.log('[AdNull] Initializing | Page type:', getPageType(), '| Blocking:', isBlockingTab);
        
        // If this is a blocking tab, run blocking sequence
        if (isBlockingTab) {
            // Wait for body to exist
            const waitForBody = () => {
                if (document.body) {
                    runBlockingTab();
                } else {
                    requestAnimationFrame(waitForBody);
                }
            };
            waitForBody();
            return;
        }
        
        // Normal page - create dashboard
        const pageType = getPageType();
        if (['feed', 'reels', 'profile', 'watch', 'other'].includes(pageType)) {
            // Wait for body to be ready
            const waitAndCreate = () => {
                if (document.body) {
                    createDashboard();
                    
                    // Request state from background
                    chrome.runtime.sendMessage({ action: 'initDashboard' }, r => {
                        if (r?.state) {
                            updateDashboard(r.state);
                        }
                    });
                    
                    // Start URL observer
                    urlObserver.observe(document.body, { childList: true, subtree: true });
                } else {
                    requestAnimationFrame(waitAndCreate);
                }
            };
            waitAndCreate();
        }
    }
    
    // Run init when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // Also run when body becomes available (for document_start)
    if (!document.body) {
        const bodyObserver = new MutationObserver((mutations, obs) => {
            if (document.body) {
                obs.disconnect();
                if (!dashboardReady && !isBlockingTab) {
                    init();
                }
            }
        });
        bodyObserver.observe(document.documentElement, { childList: true });
    }
    
})();
