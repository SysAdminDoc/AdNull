// AdNull Pro - Popup

document.addEventListener('DOMContentLoaded', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab?.url?.includes('facebook.com')) {
        document.getElementById('not-fb').style.display = 'block';
        return;
    }
    
    document.getElementById('main').style.display = 'block';
    
    // Get state
    chrome.runtime.sendMessage({ action: 'getState' }, r => {
        if (r?.state) updateUI(r.state);
    });
    
    // Buttons
    document.getElementById('start').onclick = () => {
        chrome.runtime.sendMessage({ action: 'start' });
        updateUI({ isRunning: true });
    };
    
    document.getElementById('stop').onclick = () => {
        chrome.runtime.sendMessage({ action: 'stop' });
        updateUI({ isRunning: false });
    };
    
    document.getElementById('pause').onclick = () => {
        chrome.runtime.sendMessage({ action: 'getState' }, r => {
            chrome.runtime.sendMessage({ action: r?.state?.isPaused ? 'resume' : 'pause' });
        });
    };
    
    document.getElementById('dash').onclick = async () => {
        try {
            // Try to show dashboard - may need multiple attempts
            await chrome.tabs.sendMessage(tab.id, { action: 'showDashboard' });
        } catch (e) {
            // Content script might not be ready, try injecting
            console.log('Retrying dashboard show...');
            await chrome.tabs.sendMessage(tab.id, { action: 'init' });
        }
        window.close();
    };
    
    document.getElementById('import').onclick = () => {
        chrome.runtime.sendMessage({ action: 'importFoundation', force: true });
        document.getElementById('import').textContent = '⏳...';
        setTimeout(() => { document.getElementById('import').textContent = '📥 Import List'; }, 2000);
    };
});

function updateUI(s) {
    document.getElementById('blocked').textContent = s.totalBlocked || 0;
    document.getElementById('session').textContent = s.sessionDetected || 0;
    document.getElementById('queue').textContent = s.queueLength || 0;
    
    document.getElementById('start').classList.toggle('hidden', s.isRunning);
    document.getElementById('stop').classList.toggle('hidden', !s.isRunning);
    document.getElementById('pause').textContent = s.isPaused ? '▶' : '⏸';
    
    const dot = document.getElementById('dot');
    const status = document.getElementById('status');
    
    if (s.isBlocking) { dot.className = 'status-dot blocking'; status.textContent = 'Blocking...'; }
    else if (s.isPaused) { dot.className = 'status-dot'; status.textContent = 'Paused'; }
    else if (s.isRunning) { dot.className = 'status-dot running'; status.textContent = 'Scanning...'; }
    else { dot.className = 'status-dot'; status.textContent = 'Ready'; }
}
