// AdNull Blocker Pro v8.4 - Background Service Worker
// Multi-platform ready: Facebook, TikTok, Instagram

console.log('[AdNull] ═══════════════════════════════════════════════');
console.log('[AdNull] AdNull Blocker Pro v8.4 - Service Worker');
console.log('[AdNull] ═══════════════════════════════════════════════');

// ══════════════════════════════════════════════════════════════════════
// PLATFORM DEFINITIONS (Ready for TikTok, Instagram)
// ══════════════════════════════════════════════════════════════════════
const PLATFORMS = {
    facebook: {
        name: 'Facebook',
        icon: '📘',
        urlPatterns: ['facebook.com'],
        enabled: true
    },
    tiktok: {
        name: 'TikTok',
        icon: '🎵',
        urlPatterns: ['tiktok.com'],
        enabled: false  // Future
    },
    instagram: {
        name: 'Instagram',
        icon: '📷',
        urlPatterns: ['instagram.com'],
        enabled: false  // Future
    }
};

// ══════════════════════════════════════════════════════════════════════
// DEFAULT CONFIGURATION
// ══════════════════════════════════════════════════════════════════════
const DEFAULT_CONFIG = {
    // Blocking Timing
    blockDelay: 800,           // Wait between blocks
    pageLoadWait: 1500,        // Wait for page to load
    clickDelay: 400,           // Wait between clicks
    tabCloseDelay: 500,        // Wait before closing window
    blockTimeout: 30000,       // Max time for a single block (30s)
    
    // Scanning
    scanInterval: 2000,
    autoStart: true,
    
    // Scrolling (Feed)
    scrollEnabled: true,
    scrollAmount: 800,
    scrollDelay: 2500,
    
    // Reels Auto-Skipper
    reelsSkipperEnabled: false,
    reelsSkipInterval: 100,
    
    // Features
    autoImportFoundation: true,
    showNotifications: true,
    skipSponsoredReels: true,
    showBlockButtons: true,
    
    // Background Blocking Mode
    usePopupWindow: true,  // Use popup window instead of tab (less throttled)
    focusBlockingTab: true, // Focus blocking tab to prevent throttling (recommended)
    
    // UI
    dashboardLocked: true,
    dashboardPosition: { top: 80, right: 20 },
    sectionsCollapsed: {},
    
    // Foundation
    foundationUrl: 'https://raw.githubusercontent.com/SysAdminDoc/AdNull/refs/heads/main/Blocklists/facebook_master_blocklist.csv',
    
    // GitHub Auto-Sync (optional)
    githubSyncEnabled: false,
    githubToken: '',  // Personal Access Token
    githubRepo: '',   // e.g., "username/repo"
    githubPath: '',   // e.g., "blocklists/facebook.csv"
    githubBranch: 'main'
};

const SPEED_PRESETS = {
    careful: {
        name: 'Careful', icon: '🐢',
        blockDelay: 1500, pageLoadWait: 2000, clickDelay: 600, tabCloseDelay: 500
    },
    normal: {
        name: 'Normal', icon: '🚶',
        blockDelay: 600, pageLoadWait: 1000, clickDelay: 300, tabCloseDelay: 150
    },
    fast: {
        name: 'Fast', icon: '🏃',
        blockDelay: 300, pageLoadWait: 700, clickDelay: 200, tabCloseDelay: 80
    },
    turbo: {
        name: 'Turbo', icon: '🚀',
        blockDelay: 150, pageLoadWait: 500, clickDelay: 100, tabCloseDelay: 50
    }
};

// ══════════════════════════════════════════════════════════════════════
// STATE
// ══════════════════════════════════════════════════════════════════════
let state = {
    // Config
    config: { ...DEFAULT_CONFIG },
    speedPreset: 'normal',
    
    // Data (persisted)
    masterLog: [],
    masterLogIndex: {},  // url -> index for fast lookup
    blockedSponsors: new Set(),
    whitelist: [],
    whitelistIndex: new Set(),
    blockQueue: [],
    totalBlocked: 0,
    foundationImported: false,
    
    // Runtime
    isRunning: false,
    isBlocking: false,
    isPaused: false,
    sessionDetected: 0,
    sessionBlocked: 0,
    currentBlockItem: null,
    activeBlockTabId: null,
    
    // Reels Skipper & Batch Mode
    reelsSkipperActive: false,
    reelsSkipperWasActive: false, // Track if was active before batch blocking
    reelsBatchMode: true, // Enable batch blocking for reels
    reelsBatchSize: 10, // Block when queue reaches this size
    reelsBatchInProgress: false,
    reelsTabId: null, // Track the reels tab for refresh
    
    // Platform tabs tracking
    activeTabs: new Map()
};

// ══════════════════════════════════════════════════════════════════════
// STORAGE
// ══════════════════════════════════════════════════════════════════════
async function loadState() {
    try {
        const data = await chrome.storage.local.get(null);
        
        if (data.config) state.config = { ...DEFAULT_CONFIG, ...data.config };
        if (data.speedPreset) state.speedPreset = data.speedPreset;
        if (data.masterLog) {
            state.masterLog = data.masterLog;
            rebuildMasterLogIndex();
        }
        if (data.blocked) {
            state.blockedSponsors = new Set(data.blocked);
            state.totalBlocked = data.blocked.length;
        }
        if (data.whitelist) {
            state.whitelist = data.whitelist;
            state.whitelistIndex = new Set(state.whitelist.map(e => normalizeUrl(e.url)));
        }
        if (data.queue) state.blockQueue = data.queue;
        if (data.foundationImported !== undefined) state.foundationImported = data.foundationImported;
        if (data.isRunning !== undefined) state.isRunning = data.isRunning;
        if (data.reelsBatchSize !== undefined) state.reelsBatchSize = data.reelsBatchSize;
        
        console.log('[AdNull] State loaded:', {
            blocked: state.totalBlocked,
            queue: state.blockQueue.length,
            log: state.masterLog.length,
            batchSize: state.reelsBatchSize
        });
    } catch (e) {
        console.error('[AdNull] Load error:', e);
    }
}

function rebuildMasterLogIndex() {
    state.masterLogIndex = {};
    state.masterLog.forEach((entry, i) => {
        state.masterLogIndex[normalizeUrl(entry.url)] = i;
    });
}

async function saveAll() {
    await chrome.storage.local.set({
        config: state.config,
        speedPreset: state.speedPreset,
        masterLog: state.masterLog,
        blocked: Array.from(state.blockedSponsors),
        whitelist: state.whitelist,
        queue: state.blockQueue,
        foundationImported: state.foundationImported,
        isRunning: state.isRunning
    });
}

async function saveConfig() {
    await chrome.storage.local.set({ config: state.config, speedPreset: state.speedPreset });
}

async function saveQueue() {
    await chrome.storage.local.set({ queue: state.blockQueue });
}

async function saveBlocked() {
    await chrome.storage.local.set({ blocked: Array.from(state.blockedSponsors) });
}

async function saveMasterLog() {
    await chrome.storage.local.set({ masterLog: state.masterLog });
}

// ══════════════════════════════════════════════════════════════════════
// URL UTILITIES
// ══════════════════════════════════════════════════════════════════════
function normalizeUrl(url) {
    if (!url) return '';
    try {
        const u = new URL(url);
        if (u.pathname.includes('profile.php') && u.searchParams.has('id')) {
            return `https://www.facebook.com/profile.php?id=${u.searchParams.get('id')}`;
        }
        return u.origin + u.pathname.replace(/\/$/, '');
    } catch (e) {
        return url;
    }
}

function isWhitelisted(url) {
    const norm = normalizeUrl(url);
    return state.whitelistIndex.has(norm);
}

function getPlatform(url) {
    if (!url) return null;
    for (const [key, platform] of Object.entries(PLATFORMS)) {
        if (platform.urlPatterns.some(p => url.includes(p))) {
            return key;
        }
    }
    return null;
}

function getPageType(url) {
    if (!url) return 'unknown';
    
    const platform = getPlatform(url);
    if (platform === 'facebook') {
        const path = new URL(url).pathname;
        if (path === '/' || path === '/home' || path === '/home.php') return 'feed';
        if (path.includes('/reel') || path.includes('/reels')) return 'reels';
        if (path.includes('/watch')) return 'watch';
        if (path.includes('/stories')) return 'stories';
        if (/^\/(profile\.php|[a-zA-Z0-9._-]+)\/?$/.test(path) && path.length > 1) return 'profile';
        return 'other';
    }
    return 'unknown';
}

function isBlockingTab(url) {
    return url && url.includes('__adnull_block=1');
}

// ══════════════════════════════════════════════════════════════════════
// MASTER LOG MANAGEMENT
// ══════════════════════════════════════════════════════════════════════
function addToMasterLog(data) {
    const url = normalizeUrl(data.url);
    
    // Check if already exists
    if (state.masterLogIndex[url] !== undefined) {
        return null;
    }
    
    const entry = {
        id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
        url: url,
        author: data.author || 'Unknown',
        content: data.content || '',
        source: data.source || 'feed',
        platform: data.platform || 'facebook',
        timestamp: Date.now(),
        status: 'detected'
    };
    
    // Add to beginning
    state.masterLog.unshift(entry);
    
    // Update index (shift all indices)
    const newIndex = {};
    state.masterLog.forEach((e, i) => { newIndex[normalizeUrl(e.url)] = i; });
    state.masterLogIndex = newIndex;
    
    // No size limit - keep all entries
    saveMasterLog();
    return entry;
}

function updateLogStatus(url, status, extra = {}) {
    const norm = normalizeUrl(url);
    const idx = state.masterLogIndex[norm];
    if (idx !== undefined && state.masterLog[idx]) {
        state.masterLog[idx].status = status;
        Object.assign(state.masterLog[idx], extra);
        saveMasterLog();
        return state.masterLog[idx];
    }
    return null;
}

function getLogEntry(url) {
    const norm = normalizeUrl(url);
    const idx = state.masterLogIndex[norm];
    return idx !== undefined ? state.masterLog[idx] : null;
}

// ══════════════════════════════════════════════════════════════════════
// QUEUE MANAGEMENT
// ══════════════════════════════════════════════════════════════════════
function addToQueue(item) {
    const url = normalizeUrl(item.url);
    
    if (state.blockedSponsors.has(url)) {
        console.log('[AdNull] Already blocked:', url);
        return false;
    }
    if (isWhitelisted(url)) {
        console.log('[AdNull] Whitelisted:', url);
        updateLogStatus(url, 'whitelisted');
        return false;
    }
    if (state.blockQueue.some(q => normalizeUrl(q.url) === url)) {
        return false;
    }
    
    state.blockQueue.push({
        id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
        url: url,
        author: item.author || 'Unknown',
        source: item.source || 'feed',
        platform: item.platform || 'facebook',
        addedAt: Date.now(),
        attempts: 0
    });
    
    updateLogStatus(url, 'queued');
    saveQueue();
    
    console.log('[AdNull] ➕ Queued:', item.author, '| Size:', state.blockQueue.length, '| Source:', item.source);
    
    // Check if we should trigger reels batch blocking
    if (item.source === 'reel' && state.reelsBatchMode && !state.reelsBatchInProgress) {
        if (state.blockQueue.length >= state.reelsBatchSize) {
            console.log('[AdNull] 🎬 Reels batch size reached! Starting batch block...');
            triggerReelsBatchBlock();
            return true;
        }
    }
    
    // Normal processing for feed (non-batch mode)
    if (item.source !== 'reel' && state.isRunning && !state.isBlocking && !state.isPaused) {
        processBlockQueue();
    }
    
    return true;
}

function removeFromQueue(index) {
    if (index >= 0 && index < state.blockQueue.length) {
        const item = state.blockQueue.splice(index, 1)[0];
        updateLogStatus(item.url, 'removed');
        saveQueue();
        broadcastState();
    }
}

function clearQueue() {
    state.blockQueue.forEach(item => updateLogStatus(item.url, 'cleared'));
    state.blockQueue = [];
    saveQueue();
    broadcastState();
}

// ══════════════════════════════════════════════════════════════════════
// WHITELIST
// ══════════════════════════════════════════════════════════════════════
function addToWhitelist(url, name = '') {
    const norm = normalizeUrl(url);
    if (state.whitelistIndex.has(norm)) return false;
    
    state.whitelist.unshift({
        url: norm,
        name: name || url.split('/').pop() || 'Unknown',
        addedAt: Date.now()
    });
    state.whitelistIndex.add(norm);
    
    // Remove from queue
    const idx = state.blockQueue.findIndex(q => normalizeUrl(q.url) === norm);
    if (idx >= 0) {
        state.blockQueue.splice(idx, 1);
        saveQueue();
    }
    
    updateLogStatus(norm, 'whitelisted');
    chrome.storage.local.set({ whitelist: state.whitelist });
    broadcastState();
    return true;
}

function removeFromWhitelist(url) {
    const norm = normalizeUrl(url);
    const idx = state.whitelist.findIndex(e => normalizeUrl(e.url) === norm);
    if (idx >= 0) {
        state.whitelist.splice(idx, 1);
        state.whitelistIndex.delete(norm);
        chrome.storage.local.set({ whitelist: state.whitelist });
        broadcastState();
        return true;
    }
    return false;
}

// ══════════════════════════════════════════════════════════════════════
// BLOCKING ENGINE
// ══════════════════════════════════════════════════════════════════════
async function processBlockQueue() {
    if (state.isBlocking || state.isPaused || !state.isRunning) return;
    if (state.blockQueue.length === 0) {
        broadcastStatus('Queue empty - scanning...', 'idle');
        return;
    }
    
    state.isBlocking = true;
    broadcastState();
    
    while (state.blockQueue.length > 0 && state.isRunning && !state.isPaused) {
        const item = state.blockQueue[0];
        const url = normalizeUrl(item.url);
        
        // Final checks
        if (state.blockedSponsors.has(url)) {
            state.blockQueue.shift();
            saveQueue();
            continue;
        }
        if (isWhitelisted(url)) {
            state.blockQueue.shift();
            updateLogStatus(url, 'whitelisted');
            saveQueue();
            continue;
        }
        
        item.attempts++;
        state.currentBlockItem = item;
        
        console.log('[AdNull] ══════════════════════════════════════════');
        console.log('[AdNull] 🎯 BLOCKING:', item.author);
        console.log('[AdNull] URL:', item.url);
        console.log('[AdNull] ══════════════════════════════════════════');
        
        updateLogStatus(url, 'blocking');
        broadcastStatus(`Blocking: ${item.author}...`, 'blocking');
        broadcastState();
        
        const result = await executeBlock(item);
        
        if (result.success || result.alreadyBlocked) {
            state.blockedSponsors.add(url);
            state.totalBlocked++;
            state.sessionBlocked++;
            updateLogStatus(url, result.alreadyBlocked ? 'skipped' : 'blocked', { blockedAt: Date.now() });
            await saveBlocked();
            
            console.log('[AdNull] ✓', result.alreadyBlocked ? 'Already blocked' : 'Blocked:', item.author);
            
            if (state.config.showNotifications) {
                broadcastToast(`Blocked: ${item.author}`, 'success');
            }
        } else {
            console.log('[AdNull] ✗ Failed:', item.author, result.error);
            updateLogStatus(url, 'failed', { error: result.error });
            
            // Retry once
            if (item.attempts < 2) {
                state.blockQueue.push(item);
            }
        }
        
        state.blockQueue.shift();
        state.currentBlockItem = null;
        saveQueue();
        broadcastState();
        
        if (state.blockQueue.length > 0 && state.isRunning && !state.isPaused) {
            await sleep(state.config.blockDelay);
        }
    }
    
    state.isBlocking = false;
    state.currentBlockItem = null;
    broadcastStatus(state.isRunning ? 'Scanning...' : 'Stopped', state.isRunning ? 'running' : 'stopped');
    broadcastState();
}

async function executeBlock(item) {
    console.log('[AdNull] ═══════════════════════════════════════');
    console.log('[AdNull] Starting block for:', item.author);
    console.log('[AdNull] URL:', item.url);
    console.log('[AdNull] ═══════════════════════════════════════');
    
    return new Promise(async (resolve) => {
        let tabId = null;
        let windowId = null;
        let timeoutId = null;
        let resolved = false;
        let onMessage = null;
        
        const finish = (result) => {
            if (resolved) return;
            resolved = true;
            
            console.log('[AdNull] Block result:', result.success ? 'SUCCESS' : 'FAILED', result.error || '');
            
            if (timeoutId) clearTimeout(timeoutId);
            if (onMessage) chrome.runtime.onMessage.removeListener(onMessage);
            
            // Close blocking window after a delay
            setTimeout(async () => {
                if (windowId) {
                    try { await chrome.windows.remove(windowId); } catch (e) {}
                } else if (tabId) {
                    try { await chrome.tabs.remove(tabId); } catch (e) {}
                }
            }, 1000); // Wait 1 second before closing
            
            state.activeBlockTabId = null;
            resolve(result);
        };
        
        // Message listener
        onMessage = (msg, sender) => {
            if (!sender.tab || sender.tab.id !== tabId) return;
            
            console.log('[AdNull] Received from block tab:', msg.action);
            
            if (msg.action === 'blockTabReady') {
                console.log('[AdNull] Block tab ready, sending executeBlock command...');
                
                // Wait a moment for page to stabilize, then send execute command
                setTimeout(() => {
                    chrome.tabs.sendMessage(tabId, {
                        action: 'executeBlock',
                        config: {
                            pageLoadWait: state.config.pageLoadWait || 1500,
                            clickDelay: state.config.clickDelay || 400
                        }
                    }).then(() => {
                        console.log('[AdNull] executeBlock message sent successfully');
                    }).catch(e => {
                        console.log('[AdNull] Failed to send executeBlock:', e.message);
                    });
                }, 500);
            }
            else if (msg.action === 'blockResult') {
                console.log('[AdNull] Got blockResult:', msg.result);
                finish(msg.result);
            }
            else if (msg.action === 'pageUnavailable') {
                console.log('[AdNull] Page unavailable - already blocked');
                finish({ success: false, alreadyBlocked: true });
            }
        };
        
        chrome.runtime.onMessage.addListener(onMessage);
        
        try {
            const blockUrl = item.url + (item.url.includes('?') ? '&' : '?') + '__adnull_block=1';
            console.log('[AdNull] Creating window for:', blockUrl);
            
            // Create popup window on right half of screen
            const win = await chrome.windows.create({
                url: blockUrl,
                type: 'popup',
                width: 900,
                height: 800,
                left: 960,
                top: 50,
                focused: true
            });
            
            console.log('[AdNull] Window created:', win?.id);
            
            if (!win || !win.id) {
                throw new Error('Failed to create window');
            }
            
            windowId = win.id;
            tabId = win.tabs?.[0]?.id;
            
            if (!tabId) {
                throw new Error('Window created but no tab');
            }
            
            console.log('[AdNull] Window ready - windowId:', windowId, 'tabId:', tabId);
            state.activeBlockTabId = tabId;
            
            // Timeout
            timeoutId = setTimeout(() => {
                console.log('[AdNull] ⏱ Timeout for:', item.author);
                finish({ success: false, error: 'timeout' });
            }, 35000);
            
        } catch (e) {
            console.error('[AdNull] Error in executeBlock:', e);
            finish({ success: false, error: e.message });
        }
    });
}

// Focus the blocking tab/window
async function focusBlockingTab(tabId, windowId) {
    try {
        if (windowId) {
            await chrome.windows.update(windowId, { focused: true });
        }
        await chrome.tabs.update(tabId, { active: true });
        console.log('[AdNull] Focused blocking tab');
    } catch (e) {
        console.log('[AdNull] Could not focus tab:', e.message);
    }
}

// Inject script to override visibility state and prevent throttling
async function injectVisibilityOverride(tabId) {
    try {
        await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',  // Run in page context
            func: () => {
                // Override visibility API to always report visible
                Object.defineProperty(document, 'visibilityState', {
                    get: () => 'visible',
                    configurable: true
                });
                Object.defineProperty(document, 'hidden', {
                    get: () => false,
                    configurable: true
                });
                
                // Prevent visibilitychange events
                document.addEventListener('visibilitychange', (e) => {
                    e.stopImmediatePropagation();
                }, true);
                
                // Override Page Visibility API
                if (document.hasFocus) {
                    document.hasFocus = () => true;
                }
                
                // Keep timers running at full speed
                // Create a silent audio context to prevent throttling
                try {
                    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                    const oscillator = audioCtx.createOscillator();
                    const gain = audioCtx.createGain();
                    gain.gain.value = 0; // Silent
                    oscillator.connect(gain);
                    gain.connect(audioCtx.destination);
                    oscillator.start();
                } catch (e) {}
                
                console.log('[AdNull] Visibility override injected');
            }
        });
    } catch (e) {
        console.log('[AdNull] Could not inject visibility override:', e.message);
    }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ══════════════════════════════════════════════════════════════════════
// REELS BATCH BLOCKING
// ══════════════════════════════════════════════════════════════════════
async function triggerReelsBatchBlock() {
    if (state.reelsBatchInProgress || state.isBlocking) {
        console.log('[AdNull] Batch already in progress, skipping');
        return;
    }
    
    state.reelsBatchInProgress = true;
    state.reelsSkipperWasActive = state.reelsSkipperActive;
    
    console.log('[AdNull] ══════════════════════════════════════════');
    console.log('[AdNull] 🎬 REELS BATCH BLOCKING STARTED');
    console.log('[AdNull] Queue size:', state.blockQueue.length);
    console.log('[AdNull] Skipper was active:', state.reelsSkipperWasActive);
    console.log('[AdNull] ══════════════════════════════════════════');
    
    // Stop the reels skipper
    if (state.reelsSkipperActive) {
        state.reelsSkipperActive = false;
        broadcast({ action: 'stopReelsSkipper' });
        broadcastToast('Pausing skipper for batch block...', 'info');
    }
    
    // Wait a moment for skipper to stop
    await sleep(500);
    
    // Start blocking
    state.isRunning = true;
    broadcastStatus('Batch blocking...', 'blocking');
    broadcastState();
    
    await processReelsBatch();
}

async function processReelsBatch() {
    state.isBlocking = true;
    let blockedCount = 0;
    let failedCount = 0;
    
    while (state.blockQueue.length > 0) {
        const item = state.blockQueue[0];
        const url = normalizeUrl(item.url);
        
        // Skip if already blocked
        if (state.blockedSponsors.has(url)) {
            state.blockQueue.shift();
            saveQueue();
            continue;
        }
        if (isWhitelisted(url)) {
            state.blockQueue.shift();
            updateLogStatus(url, 'whitelisted');
            saveQueue();
            continue;
        }
        
        item.attempts++;
        state.currentBlockItem = item;
        
        console.log(`[AdNull] 🎯 Batch blocking [${blockedCount + failedCount + 1}/${state.reelsBatchSize}]:`, item.author);
        
        updateLogStatus(url, 'blocking');
        broadcastStatus(`Blocking ${blockedCount + 1}/${state.reelsBatchSize}: ${item.author}`, 'blocking');
        broadcastState();
        
        const result = await executeBlock(item);
        
        if (result.success || result.alreadyBlocked) {
            state.blockedSponsors.add(url);
            state.totalBlocked++;
            state.sessionBlocked++;
            blockedCount++;
            updateLogStatus(url, result.alreadyBlocked ? 'skipped' : 'blocked', { blockedAt: Date.now() });
            await saveBlocked();
            console.log('[AdNull] ✓ Batch blocked:', item.author);
        } else {
            failedCount++;
            console.log('[AdNull] ✗ Batch failed:', item.author, result.error);
            updateLogStatus(url, 'failed', { error: result.error, failedAt: Date.now() });
        }
        
        state.blockQueue.shift();
        state.currentBlockItem = null;
        saveQueue();
        broadcastState();
        
        if (state.blockQueue.length > 0) {
            await sleep(state.config.blockDelay);
        }
    }
    
    state.isBlocking = false;
    state.currentBlockItem = null;
    
    console.log('[AdNull] ══════════════════════════════════════════');
    console.log('[AdNull] 🎬 BATCH COMPLETE:', blockedCount, 'blocked,', failedCount, 'failed');
    console.log('[AdNull] ══════════════════════════════════════════');
    
    broadcastToast(`Batch done: ${blockedCount} blocked, ${failedCount} failed`, blockedCount > 0 ? 'success' : 'warning');
    
    // Sync to GitHub if enabled
    if (state.config.githubSyncEnabled && blockedCount > 0) {
        await syncToGitHub();
    }
    
    // Complete batch and trigger refresh
    await completeReelsBatch();
}

async function completeReelsBatch() {
    console.log('[AdNull] Completing batch, navigating to fresh reels...');
    
    // Fresh reels URL - guaranteed to load new content
    const FRESH_REELS_URL = 'https://www.facebook.com/reel/?s=tab';
    
    try {
        const tabs = await chrome.tabs.query({ url: ['*://*.facebook.com/reel*', '*://*.facebook.com/reels*'] });
        if (tabs.length > 0) {
            state.reelsTabId = tabs[0].id;
            
            // Navigate to fresh reels URL instead of refreshing
            await chrome.tabs.update(tabs[0].id, { url: FRESH_REELS_URL });
            console.log('[AdNull] Navigated to fresh reels:', FRESH_REELS_URL);
            
            // Wait for page to load
            broadcastStatus('Loading fresh reels...', 'info');
            await sleep(4000);
            
            // Restart reels skipper if it was active
            if (state.reelsSkipperWasActive) {
                console.log('[AdNull] Restarting reels skipper...');
                state.reelsSkipperActive = true;
                
                // Send message to restart skipper
                try {
                    await chrome.tabs.sendMessage(tabs[0].id, { action: 'startReelsSkipper' });
                    broadcastToast('Skipper restarted, continuing scan...', 'success');
                } catch (e) {
                    console.log('[AdNull] Could not restart skipper immediately, waiting...');
                    // Retry after a delay - content script may not be ready
                    setTimeout(async () => {
                        try {
                            const newTabs = await chrome.tabs.query({ url: ['*://*.facebook.com/reel*', '*://*.facebook.com/reels*'] });
                            if (newTabs.length > 0) {
                                await chrome.tabs.sendMessage(newTabs[0].id, { action: 'startReelsSkipper' });
                                broadcastToast('Skipper restarted!', 'success');
                            }
                        } catch (e2) {
                            console.log('[AdNull] Skipper restart failed, manual restart needed');
                        }
                    }, 3000);
                }
            }
        } else {
            console.log('[AdNull] No reels tab found, opening new one...');
            await chrome.tabs.create({ url: FRESH_REELS_URL });
        }
    } catch (e) {
        console.error('[AdNull] Error navigating to reels:', e);
    }
    
    state.reelsBatchInProgress = false;
    state.reelsSkipperWasActive = false;
    broadcastStatus('Scanning reels...', 'running');
    broadcastState();
}

async function retryAllFailed() {
    let requeued = 0;
    const failedEntries = state.masterLog.filter(e => e.status === 'failed');
    
    console.log('[AdNull] Retrying', failedEntries.length, 'failed entries...');
    
    for (const entry of failedEntries) {
        const url = normalizeUrl(entry.url);
        
        // Skip if already in queue or blocked
        if (state.blockedSponsors.has(url)) continue;
        if (state.blockQueue.some(q => normalizeUrl(q.url) === url)) continue;
        
        state.blockQueue.push({
            id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
            url: url,
            author: entry.author || 'Unknown',
            source: 'retry',
            platform: entry.platform || 'facebook',
            addedAt: Date.now(),
            attempts: 0
        });
        
        updateLogStatus(url, 'queued');
        requeued++;
    }
    
    if (requeued > 0) {
        saveQueue();
        broadcastState();
        console.log('[AdNull] Requeued', requeued, 'failed entries');
        broadcastToast(`Requeued ${requeued} failed entries`, 'success');
        
        // Start processing if not already
        if (state.isRunning && !state.isBlocking && !state.reelsBatchInProgress) {
            processBlockQueue();
        }
    }
    
    return { requeued };
}

// Reprocess ALL entries - re-verify every block
async function reprocessAll() {
    let requeued = 0;
    
    console.log('[AdNull] Reprocessing ALL', state.masterLog.length, 'entries...');
    
    // Clear blocked status so they can be reprocessed
    const urlsToReprocess = [];
    
    for (const entry of state.masterLog) {
        const url = normalizeUrl(entry.url);
        if (!url) continue;
        
        // Skip if already in queue
        if (state.blockQueue.some(q => normalizeUrl(q.url) === url)) continue;
        
        urlsToReprocess.push({
            url: url,
            author: entry.author || 'Unknown',
            platform: entry.platform || 'facebook'
        });
    }
    
    // Remove from blocked set so they can be reprocessed
    for (const item of urlsToReprocess) {
        state.blockedSponsors.delete(item.url);
        
        state.blockQueue.push({
            id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
            url: item.url,
            author: item.author,
            source: 'reprocess',
            platform: item.platform,
            addedAt: Date.now(),
            attempts: 0
        });
        
        updateLogStatus(item.url, 'queued');
        requeued++;
    }
    
    if (requeued > 0) {
        await saveAll();
        broadcastState();
        console.log('[AdNull] Queued', requeued, 'entries for reprocessing');
        broadcastToast(`Queued ${requeued} entries for reprocessing`, 'success');
    }
    
    return { requeued };
}

// ══════════════════════════════════════════════════════════════════════
// FOUNDATION BLOCKLIST
// ══════════════════════════════════════════════════════════════════════
async function importFoundation(force = false) {
    if (!state.config.autoImportFoundation && !force) return { imported: 0 };
    if (state.foundationImported && !force) return { imported: 0, alreadyImported: true };
    
    console.log('[AdNull] 📥 Importing foundation blocklist...');
    broadcastStatus('Importing foundation...', 'info');
    
    try {
        const response = await fetch(state.config.foundationUrl);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const csv = await response.text();
        const lines = csv.split('\n');
        let imported = 0, skipped = 0;
        
        for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;
            
            const fields = parseCSVLine(line);
            if (fields.length < 2) continue;
            
            const author = fields[0].replace(/^"|"$/g, '').replace(/""/g, '"').trim();
            const url = normalizeUrl(fields[1].trim());
            
            if (!url || !url.includes('facebook.com')) { skipped++; continue; }
            if (state.masterLogIndex[url] !== undefined) { skipped++; continue; }
            if (state.blockedSponsors.has(url)) { skipped++; continue; }
            if (isWhitelisted(url)) { skipped++; continue; }
            
            const entry = addToMasterLog({ url, author, content: '', source: 'foundation', platform: 'facebook' });
            if (entry) {
                addToQueue({ url, author, source: 'foundation', platform: 'facebook' });
                imported++;
            }
        }
        
        state.foundationImported = true;
        await chrome.storage.local.set({ foundationImported: true });
        
        console.log('[AdNull] Foundation imported:', imported, 'skipped:', skipped);
        broadcastToast(`Foundation: ${imported} imported`, 'success');
        broadcastStatus(`Foundation: ${imported} imported`, 'success');
        broadcastState();
        
        return { imported, skipped };
    } catch (e) {
        console.error('[AdNull] Foundation error:', e);
        broadcastToast('Foundation import failed', 'error');
        return { imported: 0, error: e.message };
    }
}

function parseCSVLine(line) {
    const result = [];
    let current = '', inQuotes = false;
    for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (c === '"') {
            if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
            else inQuotes = !inQuotes;
        } else if (c === ',' && !inQuotes) {
            result.push(current); current = '';
        } else current += c;
    }
    result.push(current);
    return result;
}

// ══════════════════════════════════════════════════════════════════════
// GITHUB AUTO-SYNC
// ══════════════════════════════════════════════════════════════════════
async function syncToGitHub() {
    const { githubSyncEnabled, githubToken, githubRepo, githubPath, githubBranch } = state.config;
    
    console.log('[AdNull] GitHub sync check:', {
        enabled: githubSyncEnabled,
        hasToken: !!githubToken,
        repo: githubRepo,
        path: githubPath,
        branch: githubBranch
    });
    
    if (!githubToken || !githubRepo || !githubPath) {
        console.log('[AdNull] GitHub sync not configured - missing required fields');
        return { success: false, error: 'Missing token, repo, or path' };
    }
    
    console.log('[AdNull] 📤 Syncing to GitHub...');
    console.log('[AdNull] Repo:', githubRepo, 'Path:', githubPath, 'Branch:', githubBranch);
    broadcastStatus('Syncing to GitHub...', 'info');
    
    try {
        // Generate CSV content from blocked sponsors
        const csvContent = generateBlocklistCSV();
        console.log('[AdNull] CSV generated, lines:', csvContent.split('\n').length);
        
        // Base64 encode properly for GitHub API
        const content = btoa(String.fromCharCode(...new TextEncoder().encode(csvContent)));
        
        // Clean up path (remove leading slash if present)
        const cleanPath = githubPath.replace(/^\//, '');
        const branch = githubBranch || 'main';
        
        // First, get the current file SHA (needed for updates)
        let sha = null;
        const getUrl = `https://api.github.com/repos/${githubRepo}/contents/${cleanPath}?ref=${branch}`;
        console.log('[AdNull] Checking existing file:', getUrl);
        
        try {
            const getResponse = await fetch(getUrl, {
                headers: {
                    'Authorization': `Bearer ${githubToken}`,
                    'Accept': 'application/vnd.github.v3+json',
                    'X-GitHub-Api-Version': '2022-11-28'
                }
            });
            
            console.log('[AdNull] GET response status:', getResponse.status);
            
            if (getResponse.ok) {
                const fileData = await getResponse.json();
                sha = fileData.sha;
                console.log('[AdNull] Existing file SHA:', sha);
            } else if (getResponse.status === 404) {
                console.log('[AdNull] File does not exist, will create new');
            } else {
                const errText = await getResponse.text();
                console.log('[AdNull] GET error:', getResponse.status, errText);
            }
        } catch (e) {
            console.log('[AdNull] Error checking file:', e.message);
        }
        
        // Create/update the file
        const putUrl = `https://api.github.com/repos/${githubRepo}/contents/${cleanPath}`;
        const body = {
            message: `AdNull auto-sync: ${state.blockedSponsors.size} blocked sponsors (${new Date().toISOString()})`,
            content: content,
            branch: branch
        };
        if (sha) body.sha = sha;
        
        console.log('[AdNull] PUT request to:', putUrl);
        console.log('[AdNull] Body (without content):', { ...body, content: `[${content.length} chars]` });
        
        const response = await fetch(putUrl, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${githubToken}`,
                'Accept': 'application/vnd.github.v3+json',
                'Content-Type': 'application/json',
                'X-GitHub-Api-Version': '2022-11-28'
            },
            body: JSON.stringify(body)
        });
        
        console.log('[AdNull] PUT response status:', response.status);
        
        const responseText = await response.text();
        console.log('[AdNull] PUT response:', responseText.substring(0, 500));
        
        if (!response.ok) {
            let errorMsg = `HTTP ${response.status}`;
            try {
                const errorData = JSON.parse(responseText);
                errorMsg = errorData.message || errorMsg;
                if (errorData.errors) {
                    errorMsg += ': ' + errorData.errors.map(e => e.message || e.code).join(', ');
                }
            } catch (e) {}
            throw new Error(errorMsg);
        }
        
        const result = JSON.parse(responseText);
        console.log('[AdNull] ✓ GitHub sync complete:', result.commit?.sha?.substring(0, 7));
        broadcastToast('GitHub sync complete!', 'success');
        
        return { success: true, commit: result.commit?.sha };
        
    } catch (e) {
        console.error('[AdNull] GitHub sync error:', e);
        console.error('[AdNull] Error stack:', e.stack);
        broadcastToast(`GitHub sync failed: ${e.message}`, 'error');
        return { success: false, error: e.message };
    }
}

function generateBlocklistCSV() {
    const lines = ['"Author","URL","Platform","Blocked At"'];
    
    // Get all blocked entries from master log
    const blockedEntries = state.masterLog.filter(e => 
        e.status === 'blocked' || e.status === 'skipped' || state.blockedSponsors.has(normalizeUrl(e.url))
    );
    
    for (const entry of blockedEntries) {
        const author = (entry.author || 'Unknown').replace(/"/g, '""');
        const url = entry.url || '';
        const platform = entry.platform || 'facebook';
        const blockedAt = entry.blockedAt ? new Date(entry.blockedAt).toISOString() : '';
        lines.push(`"${author}","${url}","${platform}","${blockedAt}"`);
    }
    
    // Also include sponsors that might not be in log
    for (const url of state.blockedSponsors) {
        const inLog = blockedEntries.some(e => normalizeUrl(e.url) === url);
        if (!inLog) {
            lines.push(`"Unknown","${url}","facebook",""`);
        }
    }
    
    return lines.join('\n');
}

async function testGitHubConnection() {
    const { githubToken, githubRepo } = state.config;
    
    if (!githubToken || !githubRepo) {
        return { success: false, error: 'Token and repo required' };
    }
    
    console.log('[AdNull] Testing GitHub connection to:', githubRepo);
    
    try {
        const response = await fetch(
            `https://api.github.com/repos/${githubRepo}`,
            {
                headers: {
                    'Authorization': `Bearer ${githubToken}`,
                    'Accept': 'application/vnd.github.v3+json',
                    'X-GitHub-Api-Version': '2022-11-28'
                }
            }
        );
        
        console.log('[AdNull] Test response status:', response.status);
        
        if (!response.ok) {
            const errorText = await response.text();
            console.log('[AdNull] Test error:', errorText);
            let errorMsg = `HTTP ${response.status}`;
            try {
                const error = JSON.parse(errorText);
                errorMsg = error.message || errorMsg;
            } catch (e) {}
            throw new Error(errorMsg);
        }
        
        const repo = await response.json();
        console.log('[AdNull] Test success:', repo.full_name, 'permissions:', repo.permissions);
        
        // Check if we have push permission
        if (repo.permissions && !repo.permissions.push) {
            return { 
                success: false, 
                error: 'Token does not have write access to this repo. Check token scopes.' 
            };
        }
        
        return { success: true, repoName: repo.full_name, private: repo.private };
        
    } catch (e) {
        console.error('[AdNull] Test error:', e);
        return { success: false, error: e.message };
    }
}

// ══════════════════════════════════════════════════════════════════════
// SCANNING & SCROLLING CONTROL
// ══════════════════════════════════════════════════════════════════════
const SCAN_ALARM = 'adnull_scan';
const SCROLL_ALARM = 'adnull_scroll';

async function startScanning() {
    if (state.isRunning) return;
    
    state.isRunning = true;
    state.isPaused = false;
    await chrome.storage.local.set({ isRunning: true });
    
    console.log('[AdNull] ▶ Started');
    
    await chrome.alarms.clear(SCAN_ALARM);
    await chrome.alarms.clear(SCROLL_ALARM);
    
    chrome.alarms.create(SCAN_ALARM, { delayInMinutes: 0.05, periodInMinutes: state.config.scanInterval / 60000 });
    if (state.config.scrollEnabled) {
        chrome.alarms.create(SCROLL_ALARM, { delayInMinutes: 0.1, periodInMinutes: state.config.scrollDelay / 60000 });
    }
    
    await scanAllTabs();
    
    if (state.blockQueue.length > 0 && !state.isBlocking) {
        processBlockQueue();
    }
    
    broadcastStatus('Scanning...', 'running');
    broadcastState();
}

async function stopScanning() {
    state.isRunning = false;
    state.isPaused = false;
    await chrome.storage.local.set({ isRunning: false });
    await chrome.alarms.clear(SCAN_ALARM);
    await chrome.alarms.clear(SCROLL_ALARM);
    
    console.log('[AdNull] ⏹ Stopped');
    broadcastStatus('Stopped', 'stopped');
    broadcastState();
}

async function pauseScanning() {
    state.isPaused = true;
    broadcastStatus('Paused', 'paused');
    broadcastState();
}

async function resumeScanning() {
    if (!state.isRunning) return startScanning();
    state.isPaused = false;
    if (state.blockQueue.length > 0 && !state.isBlocking) processBlockQueue();
    broadcastStatus('Scanning...', 'running');
    broadcastState();
}

async function scanAllTabs() {
    if (!state.isRunning || state.isPaused) return;
    
    try {
        const tabs = await chrome.tabs.query({ url: ['*://*.facebook.com/*'] });
        for (const tab of tabs) {
            if (!tab.url || isBlockingTab(tab.url)) continue;
            const pageType = getPageType(tab.url);
            if (pageType === 'feed' || pageType === 'reels') {
                try { await chrome.tabs.sendMessage(tab.id, { action: 'scan' }); } catch (e) {}
            }
        }
    } catch (e) {}
}

async function scrollAllTabs() {
    if (!state.isRunning || state.isPaused || !state.config.scrollEnabled) return;
    
    try {
        const tabs = await chrome.tabs.query({ url: ['*://*.facebook.com/*'] });
        for (const tab of tabs) {
            if (!tab.url || isBlockingTab(tab.url)) continue;
            if (getPageType(tab.url) === 'feed') {
                try { await chrome.tabs.sendMessage(tab.id, { action: 'scroll', amount: state.config.scrollAmount }); } catch (e) {}
            }
        }
    } catch (e) {}
}

chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm.name === SCAN_ALARM) scanAllTabs();
    else if (alarm.name === SCROLL_ALARM) scrollAllTabs();
});

// ══════════════════════════════════════════════════════════════════════
// BROADCASTING
// ══════════════════════════════════════════════════════════════════════
async function broadcast(message) {
    try {
        const tabs = await chrome.tabs.query({ url: ['*://*.facebook.com/*'] });
        for (const tab of tabs) {
            try { await chrome.tabs.sendMessage(tab.id, message); } catch (e) {}
        }
    } catch (e) {}
}

function broadcastState() {
    broadcast({
        action: 'stateUpdate',
        state: getPublicState()
    });
    updateBadge();
}

// Update extension icon badge with queue count
function updateBadge() {
    const queueCount = state.blockQueue.length;
    
    if (queueCount > 0) {
        // Show queue count
        chrome.action.setBadgeText({ text: queueCount.toString() });
        
        // Color based on state
        if (state.isBlocking || state.reelsBatchInProgress) {
            chrome.action.setBadgeBackgroundColor({ color: '#1877f2' }); // Blue - blocking
        } else if (state.isRunning) {
            chrome.action.setBadgeBackgroundColor({ color: '#42b72a' }); // Green - scanning
        } else {
            chrome.action.setBadgeBackgroundColor({ color: '#f7b928' }); // Yellow - queued but stopped
        }
    } else {
        // Show total blocked or clear
        if (state.totalBlocked > 0) {
            const display = state.totalBlocked > 999 ? '999+' : state.totalBlocked.toString();
            chrome.action.setBadgeText({ text: display });
            chrome.action.setBadgeBackgroundColor({ color: '#65676b' }); // Gray - idle
        } else {
            chrome.action.setBadgeText({ text: '' });
        }
    }
}

function broadcastStatus(text, type) {
    broadcast({ action: 'updateStatus', status: text, type });
}

function broadcastToast(message, type) {
    broadcast({ action: 'showToast', message, type });
}

function getPublicState() {
    // Count failed items
    const failedCount = state.masterLog.filter(e => e.status === 'failed').length;
    
    return {
        isRunning: state.isRunning,
        isPaused: state.isPaused,
        isBlocking: state.isBlocking,
        totalBlocked: state.totalBlocked,
        sessionDetected: state.sessionDetected,
        sessionBlocked: state.sessionBlocked,
        queueLength: state.blockQueue.length,
        whitelistLength: state.whitelist.length,
        logLength: state.masterLog.length,
        failedCount: failedCount,
        currentBlockItem: state.currentBlockItem,
        blockQueue: state.blockQueue,
        whitelist: state.whitelist,
        masterLog: state.masterLog,
        config: state.config,
        speedPreset: state.speedPreset,
        foundationImported: state.foundationImported,
        reelsSkipperActive: state.reelsSkipperActive,
        reelsBatchMode: state.reelsBatchMode,
        reelsBatchSize: state.reelsBatchSize,
        reelsBatchInProgress: state.reelsBatchInProgress
    };
}

// ══════════════════════════════════════════════════════════════════════
// MESSAGE HANDLER
// ══════════════════════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    const handle = async () => {
        try {
            switch (msg.action) {
                // State
                case 'getState':
                    return { success: true, state: getPublicState() };
                
                // Control
                case 'start': await startScanning(); return { success: true };
                case 'stop': await stopScanning(); return { success: true };
                case 'pause': await pauseScanning(); return { success: true };
                case 'resume': await resumeScanning(); return { success: true };
                
                // Sponsor detection
                case 'sponsorFound':
                    const entry = addToMasterLog(msg.data);
                    if (entry) {
                        state.sessionDetected++;
                        addToQueue(msg.data);
                    }
                    broadcastState();
                    return { success: true, isNew: !!entry };
                
                // Blocking tab communication
                case 'blockTabReady':
                case 'blockResult':
                case 'pageUnavailable':
                    return { success: true };
                
                // Queue
                case 'addToQueue':
                    addToQueue(msg.item);
                    return { success: true };
                case 'removeFromQueue':
                    removeFromQueue(msg.index);
                    return { success: true };
                case 'clearQueue':
                    clearQueue();
                    return { success: true };
                case 'moveToTop':
                    if (msg.index > 0 && msg.index < state.blockQueue.length) {
                        const item = state.blockQueue.splice(msg.index, 1)[0];
                        state.blockQueue.unshift(item);
                        saveQueue();
                        broadcastState();
                    }
                    return { success: true };
                case 'requeueFailed':
                case 'retryAllFailed':
                    const retryResult = await retryAllFailed();
                    return { success: true, requeued: retryResult.requeued };
                
                case 'reprocessAll':
                    const reprocessResult = await reprocessAll();
                    return { success: true, requeued: reprocessResult.requeued };
                
                // Reels batch control
                case 'setReelsBatchSize':
                    state.reelsBatchSize = Math.max(1, Math.min(500, msg.size || 10));
                    await chrome.storage.local.set({ reelsBatchSize: state.reelsBatchSize });
                    console.log('[AdNull] Batch size set to:', state.reelsBatchSize);
                    broadcastState();
                    return { success: true, size: state.reelsBatchSize };
                case 'triggerBatchNow':
                    if (state.blockQueue.length > 0 && !state.reelsBatchInProgress) {
                        triggerReelsBatchBlock();
                    }
                    return { success: true };
                
                // Whitelist
                case 'addToWhitelist':
                    return { success: true, added: addToWhitelist(msg.url, msg.name) };
                case 'removeFromWhitelist':
                    removeFromWhitelist(msg.url);
                    return { success: true };
                
                // GitHub Sync
                case 'syncToGitHub':
                    return await syncToGitHub();
                case 'testGitHub':
                    return await testGitHubConnection();
                case 'setGitHubConfig':
                    state.config.githubSyncEnabled = msg.enabled ?? state.config.githubSyncEnabled;
                    state.config.githubToken = msg.token ?? state.config.githubToken;
                    state.config.githubRepo = msg.repo ?? state.config.githubRepo;
                    state.config.githubPath = msg.path ?? state.config.githubPath;
                    state.config.githubBranch = msg.branch ?? state.config.githubBranch;
                    await saveConfig();
                    broadcastState();
                    return { success: true };
                
                // Config
                case 'setConfig':
                    state.config = { ...state.config, ...msg.config };
                    await saveConfig();
                    // Update alarms if needed
                    if (state.isRunning) {
                        if (msg.config.scanInterval) {
                            await chrome.alarms.clear(SCAN_ALARM);
                            chrome.alarms.create(SCAN_ALARM, { periodInMinutes: state.config.scanInterval / 60000 });
                        }
                        if (msg.config.scrollDelay || msg.config.scrollEnabled !== undefined) {
                            await chrome.alarms.clear(SCROLL_ALARM);
                            if (state.config.scrollEnabled) {
                                chrome.alarms.create(SCROLL_ALARM, { periodInMinutes: state.config.scrollDelay / 60000 });
                            }
                        }
                    }
                    broadcastState();
                    return { success: true };
                
                case 'setSpeedPreset':
                    const preset = SPEED_PRESETS[msg.preset];
                    if (preset) {
                        state.speedPreset = msg.preset;
                        state.config = { ...state.config, ...preset };
                        delete state.config.name; delete state.config.icon;
                        await saveConfig();
                        broadcastState();
                    }
                    return { success: true };
                
                case 'setDashboardLocked':
                    state.config.dashboardLocked = msg.locked;
                    await saveConfig();
                    broadcastState();
                    return { success: true };
                
                case 'setSectionCollapsed':
                    state.config.sectionsCollapsed = { ...state.config.sectionsCollapsed, [msg.section]: msg.collapsed };
                    await saveConfig();
                    return { success: true };
                
                // Foundation
                case 'importFoundation':
                    const result = await importFoundation(msg.force);
                    return { success: true, result };
                
                // Reels Skipper
                case 'setReelsSkipper':
                    state.reelsSkipperActive = msg.active;
                    state.config.reelsSkipperEnabled = msg.active;
                    await saveConfig();
                    broadcastState();
                    return { success: true };
                
                // Export/Import
                case 'exportData':
                    return {
                        success: true,
                        data: {
                            masterLog: state.masterLog,
                            whitelist: state.whitelist,
                            blocked: Array.from(state.blockedSponsors)
                        }
                    };
                case 'importData':
                    let importCount = 0;
                    for (const e of msg.entries) {
                        if (addToMasterLog(e)) {
                            if (!state.blockedSponsors.has(normalizeUrl(e.url))) {
                                addToQueue({ url: e.url, author: e.author, source: 'import' });
                            }
                            importCount++;
                        }
                    }
                    broadcastState();
                    return { success: true, imported: importCount };
                
                // Clear
                case 'clearAllData':
                    state.masterLog = [];
                    state.masterLogIndex = {};
                    state.blockedSponsors.clear();
                    state.whitelist = [];
                    state.whitelistIndex.clear();
                    state.blockQueue = [];
                    state.totalBlocked = 0;
                    state.sessionDetected = 0;
                    state.sessionBlocked = 0;
                    state.foundationImported = false;
                    await saveAll();
                    broadcastState();
                    return { success: true };
                
                case 'clearLog':
                    state.masterLog = [];
                    state.masterLogIndex = {};
                    await saveMasterLog();
                    broadcastState();
                    return { success: true };
                
                case 'resetConfig':
                    state.config = { ...DEFAULT_CONFIG };
                    state.speedPreset = 'normal';
                    await saveConfig();
                    broadcastState();
                    return { success: true };
                
                // Init dashboard
                case 'initDashboard':
                    // Force send current state
                    if (sender.tab) {
                        try {
                            await chrome.tabs.sendMessage(sender.tab.id, {
                                action: 'stateUpdate',
                                state: getPublicState()
                            });
                        } catch (e) {}
                    }
                    return { success: true, state: getPublicState() };
                
                default:
                    return { success: false, error: 'Unknown action' };
            }
        } catch (e) {
            console.error('[AdNull] Message error:', e);
            return { success: false, error: e.message };
        }
    };
    
    handle().then(sendResponse);
    return true;
});

// ══════════════════════════════════════════════════════════════════════
// TAB EVENTS
// ══════════════════════════════════════════════════════════════════════
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        const platform = getPlatform(tab.url);
        if (platform && !isBlockingTab(tab.url)) {
            // Notify content script to init
            chrome.tabs.sendMessage(tabId, { 
                action: 'init',
                state: getPublicState()
            }).catch(() => {});
        }
    }
});

chrome.tabs.onRemoved.addListener(tabId => {
    state.activeTabs.delete(tabId);
});

// ══════════════════════════════════════════════════════════════════════
// INITIALIZATION
// ══════════════════════════════════════════════════════════════════════
async function initialize() {
    console.log('[AdNull] Initializing...');
    await loadState();
    
    // Import foundation if needed
    if (state.config.autoImportFoundation && !state.foundationImported) {
        setTimeout(() => importFoundation(), 2000);
    }
    
    // Resume if was running
    if (state.isRunning) {
        console.log('[AdNull] Resuming...');
        chrome.alarms.create(SCAN_ALARM, { periodInMinutes: state.config.scanInterval / 60000 });
        if (state.config.scrollEnabled) {
            chrome.alarms.create(SCROLL_ALARM, { periodInMinutes: state.config.scrollDelay / 60000 });
        }
        if (state.blockQueue.length > 0 && !state.isBlocking) {
            setTimeout(() => processBlockQueue(), 2000);
        }
    }
    
    console.log('[AdNull] Ready | Queue:', state.blockQueue.length, '| Blocked:', state.totalBlocked);
}

initialize();
