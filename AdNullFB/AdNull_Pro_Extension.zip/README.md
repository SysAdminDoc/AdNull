# AdNull Blocker Pro v8.0

Professional ad blocker for Facebook with TikTok & Instagram support coming soon.

## 🆕 What's New in v8.0

### Fixed Issues
- **Dashboard appears on first load** - No more refreshing needed
- **Fast tab closing** - Already blocked pages close immediately
- **Full activity log** - ALL entries shown, scrollable

### New Features
- **Page State Indicator** - Shows Feed 📰, Reels 🎬, Profile 👤
- **Reels Auto-Skipper** - Rapidly skip reels for ad detection
- **Multi-platform ready** - Architecture for TikTok & Instagram

## Installation

1. Extract the zip
2. Go to `chrome://extensions/`
3. Enable Developer mode
4. Click Load unpacked → select folder
5. Open Facebook!

## Features

- Auto-detect sponsored posts and reels
- Block advertisers with one click
- Import community blocklist
- Whitelist protection
- Export/import data
- Speed presets (Careful → Turbo)
- Full timing control
